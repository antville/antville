/**
 * macro rendering a skin
 */
function skin_macro(param) {
   if (param.name)
      this.renderSkin(param.name);
   return;
}


/**
 * generic macro that loops over the childobjects
 * and renders a specified skin for each of them
 */
function loop_macro(param) {
   if (!param.skin)
      return;
   for (var i=0;i<this.size();i++)
      this.get(i).renderSkin(param.skin);
   return;
}


/**
 * macro returns the url for any hopobject
 */
function href_macro(param) {
   return this.href(param.action ? param.action : "");
}


/**
 * macro returns the id of a HopObject
 */
function id_macro(param) {
   return this._id;
}

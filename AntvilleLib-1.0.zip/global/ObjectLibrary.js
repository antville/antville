ObjectLib = {
   version: "0.2",

   getVersion: function() {
      return this.version;
   },

   clone: function(origObj) {
      var cloneObj = new Object();
      for (var p in origObj)
         cloneObj[p] = origObj[p];
      return cloneObj;
   }
}

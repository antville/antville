/**
 * macro rendering a skin
 */
function skin_macro(param) {
   if (!param.name)
      return;
   if (param.asis == "true")
      var str = app.skinfiles[this._prototype][param.name];
   else
      var str = this.renderSkinAsString(param.name);
   if (param.unwrap == "true")
      str = str.unwrap();
   res.write(str);
   return;
}


/**
 * generic macro that loops over the childobjects
 * and renders a specified skin for each of them
 */
function loop_macro(param) {
   if (!param.skin)
      return;
   var items = param.collection ? this[param.collection] : this;
   if (!items || !items.size)
      return;
   var max = items.size();
   if (param.paging == "true") {
      var pagesize = parseInt(param.limit, 10);
      if (isNaN(param.limit))
         pagesize = 10;
      var pagenr = parseInt(req.data.page, 10);
      if (isNaN(pagenr))
         pagenr = 0;
      var min = Math.min(max, pagenr * pagesize)
      var max = Math.min(max, min + pagesize);
   } else
      var min = 0;
   for (var i=min; i<max; i++)
      items.get(i).renderSkin(param.skin);
   return;
}


/**
 * macro returns the url for any hopobject
 */
function href_macro(param) {
   return this.href(param.action ? param.action : "");
}


/**
 * macro returns the id of a HopObject
 */
function id_macro(param) {
   return this._id;
}

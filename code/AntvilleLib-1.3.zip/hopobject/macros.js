/**
 * macro rendering a skin
 */
function skin_macro(param) {
   if (!param.name)
      return;
   if (param.asis == "true")
      var str = app.skinfiles[this._prototype][param.name];
   else
      var str = this.renderSkinAsString(param.name);
   if (param.unwrap == "true")
      str = str.unwrap();
   res.write(str);
   return;
}


/**
 * generic macro that loops over the childobjects
 * and renders a specified skin for each of them
 */
function loop_macro(param) {
   if (!param.skin)
      return;
   var items = param.collection ? this[param.collection] : this;
   if (!items || !items.size)
      return;
   var max = items.size();
   for (var i=0; i<max; i++)
      items.get(i).renderSkin(param.skin);
   return;
   return;
}


/**
 * macro returns the url for any hopobject
 */
function href_macro(param) {
   return this.href(param.action ? param.action : "");
}


/**
 * macro returns the id of a HopObject
 */
function id_macro(param) {
   return this._id;
}

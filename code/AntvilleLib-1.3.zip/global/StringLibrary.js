String.ANUMPATTERN     = /[^a-zA-Z0-9]/;
String.APATTERN        = /[^a-zA-Z]/;
String.NUMPATTERN      = /[^0-9]/;
String.URLPATTERN      = /[^a-zA-Z0-9$-_\.\+\!\*\'()\,#%~\\ ]/;
String.FILEPATTERN     = /[^a-zA-Z0-9-_\. ]/;
String.HEXPATTERN      = /[^a-fA-F0-9]/;
String.LEFT            = -1
String.BALANCE         = 0
String.RIGHT           = 1

////////////////////
// DEPRECATED
// keep this block for a while for b/w compatibility...
StringLib = {
   version: "1.1",
   toString: function() {
      return "[Antville StringLibrary]";
   },
   getVersion: function() {
      return this.version;
   },
   random: String.random
}
String.prototype.wrap            = String.prototype.softwrap
String.prototype.ANUMPATTERN     = String.ANUMPATTERN
String.prototype.APATTERN        = String.APATTERN   
String.prototype.NUMPATTERN      = String.NUMPATTERN 
String.prototype.URLPATTERN      = String.URLPATTERN 
String.prototype.FILEPATTERN     = String.FILEPATTERN
String.prototype.HEXPATTERN      = String.HEXPATTERN 
////////////////////

/**
 * creates a random string (numbers and chars)
 * @param len length of key
 * @param mode determines which letters to use. null or 0 = all letters;
 *     1 = skip 0, 1, l and o which can easily be mixed with numbers;
 *     2 = use numbers only
 * @returns random string
 */
String.random = function(len, mode) {
   if (mode == 2) {
      var x = Math.random() * Math.pow(10,len);
      return Math.floor(x);
   }
   var keystr = "";
   for (var i=0; i<len; i++) {
      var x = Math.floor((Math.random() * 36));
      if (mode == 1) {
         // skip 0,1
         x = (x<2) ? x + 2 : x;
         // don't use the letters l (charCode 21+87) and o (24+87)
         x = (x==21) ? 22 : x;
         x = (x==24) ? 25 : x;
      }
      if (x<10) {
         keystr += String(x);
      }   else   {
         keystr += String.fromCharCode(x+87);
      }
   }
   return keystr;
}

/**
 * append one string onto another and add some "glue"
 * if none of the strings is empty or null.
 * @param String the first string
 * @param String the string to be appended onto the first one
 * @param String the "glue" to be inserted between both strings
 * @return String the resulting string
 */
String.join = function(str1, str2, glue) {
   if (glue == null)
      glue = "";
   if (str1 && str2)
      return str1 + glue + str2;
   else if (str2)
      return str2;
   return str1;
}

/**
 * function checks if the string passed contains any
 * non-alphanumeric characters
 * @return Boolean
 */
String.prototype.isClean = function() {
   return !String.ANUMPATTERN.test(this);
}

/**
 * function cleans a string by throwing away all
 * non-alphanumeric characters
 * @return cleaned string
 */
String.prototype.clean = function() {
   return this.replace(new RegExp(String.ANUMPATTERN.source, "g"), "");
}

/**
 * function checks if the string passed contains any characters that
 * are forbidden in URLs
 * @return Boolean
 */
String.prototype.isURL = function() {
   return !String.URLPATTERN.test(this);
}

/**
 * function cleans a string passed as argument from any
 * characters that are forbidden in URLs
 * @return cleaned string
 */
String.prototype.toURL = function () {
   return this.replace(new RegExp(String.URLPATTERN.source, "g"), "");
}

/**
 * function checks if the string passed contains any characters
 * that are forbidden in image- or filenames
 * @return Boolean
 */
String.prototype.isFileName = function() {
   return !String.FILEPATTERN.test(this);
}

/**
 * function cleans the string passed as argument from any characters
 * that are forbidden or shouldn't be used in filenames
 * @return Boolean
 */
String.prototype.toFileName = function() {
   return this.replace(new RegExp(String.FILEPATTERN.source, "g"), "");
}

/**
 * checks if a date format pattern is correct
 * @return Boolean true if the pattern is correct
 */
String.prototype.isDateFormat = function() {
   try {
      new java.text.SimpleDateFormat(this);
      return true;
   } catch (err) {
      return false;
   }
}

/**
 * function checks a string for a valid color value in hexadecimal format.
 * it may also contain # as first character
 *  @returns Boolean false, if string length (without #) > 6 or < 6 or
 *           contains any character which is not a valid hex value
 */
String.prototype.isHexColor = function() {
   var str = this;
   if (this.indexOf("#") == 0)
      str = this.substring(1);
   if (str.length != 6)
      return false;
   return !String.HEXPATTERN.test(str);
}

/**
 * converts a string into a hexadecimal color
 * representation (e.g. "ffcc33"). also knows how to
 * convert a color string like "rgb (255, 204, 51)".
 * @return String the resulting hex color (w/o "#")
 */
String.prototype.toHexColor = function() {
   if (this.startsWith("rgb")) {
      var result = new java.lang.StringBuffer();
      var col = this.replace(/[^0-9,]/g,"");
      var parts = col.split(",");
      for (var i in parts) {
         var num = parseInt(parts[i], 10);
         var hex = num.toString(16);
         result.append(hex.pad("0", 2, String.LEFT));
      }
      return result;
   }
   var col = this.replace(new RegExp(String.HEXPATTERN.source), "");
   return col.toLowerCase().pad("0", 6, String.LEFT);
}

/**
 * function returns true if the string contains
 * only a-z and 0-9 (case insensitive!)
 * @return Boolean true in case string is alpha, false otherwise
 */
String.prototype.isAlphanumeric = function() {
   if (!this.length)
      return false;
   return !String.ANUMPATTERN.test(this);
}

/**
 * function returns true if the string contains
 * only characters a-z
 * @return Boolean true in case string is alpha, false otherwise
 */
String.prototype.isAlpha = function() {
   if (!this.length)
      return false;
   return !String.APATTERN.test(this);
}

/**
 * function returns true if the string contains
 * only 0-9
 * @return Boolean true in case string is numeric, false otherwise
 */
String.prototype.isNumeric = function() {
   if (!this.length)
      return false;
   return !String.NUMPATTERN.test(this);
}

/**
 * parse a timestamp into a date object. This is used when  users
 * want to set createtime explicitly when creating/editing stories.
 * @param String date format to be applied
 * @param Object Java TimeZone Object (optional)
 * @return Object contains the resulting date
 */
String.prototype.toDate = function(format, timezone) {
   var sdf = res.data["_dateformat"];
   if (!sdf)
      sdf = new java.text.SimpleDateFormat(format);
   if (timezone && sdf.getTimeZone() != timezone)
      sdf.setTimeZone(timezone);
   // FIXME: create a new Date Object and return it
   // otherwise we would return a Java Date Object
   return new Date(sdf.parse(this).getTime());
}

/**
 * function parses a string and converts any
 * found URL into a HTML link tag
 * @return String resulting string with activated URLs
 */
String.prototype.activateURLs = function() {
   var pre = '<a href="';
   var mid = '">';
   var post = '</a>';
   var re = /(^|\/>|\s+)([fhtpsr]+:\/\/[^\s]+?)([\.,;:\)\]\"]?)(?=[\s<]|$)/gim;
   return this.replace(re, "$1" + pre + "$2" + mid + "$2" + post + "$3");
}

/**
 * translates all characters of a string into HTML entities
 * @return String translated result
 */
String.prototype.entitize = function() {
   var result = new java.lang.StringBuffer();
   for (var i=0; i<this.length; i++) {
      result.append("&#");
      result.append(this.charCodeAt(i).toString());
      result.append(";");
   }
   return result.toString();
}

/**
 * function retuns only a part of the string passed as argument
 * length of the string to show is defined by argument "limit"
 * clipping is always done at the first space <em>after</em> the
 * limit
 * @param String to be clipped
 * @param Int desired length of string
 * @param Boolean definitely cut after limit (ignore whitespace)
 * @return String clipped string
 */
String.prototype.clip = function(limit, clipping, ignoreWhiteSpace) {
   if (!limit)
      return this;
   var str = stripTags(this);
   if (str.length <= limit)
      return str;
   if (!clipping)
      clipping = "...";
   var cut = (ignoreWhiteSpace == true) ? limit : str.indexOf(" ", limit);
   if (cut < 0)
      return str;
   return str.substring(0, cut) + clipping;
   // the same can be achieved with the following single line:
   // return this.dissect(limit, clipping, ignoreWhiteSpace).head;
}

/**
 * function inserts a string every number of characters
 * @param Int number of characters after which insertion should take place
 * @param String string to be inserted
 * @param Boolean definitely insert at each interval position
 * @return String resulting string
 */
String.prototype.group = function(interval, str, ignoreWhiteSpace) {
   if (!str || this.length < interval)
      return this;
   var buf = new java.lang.StringBuffer();
   for (var i=0; i<this.length; i=i+interval) {
      var strPart = this.substring(i, i+interval);
      buf.append(strPart);
      if (ignoreWhiteSpace == true || (strPart.length == interval && strPart.indexOf(" ") < 0))
         buf.append(str);
   }
   return buf.toString();
}

/**
 * function softwraps a string every number of characters
 * (ie. inserts <wbr /> at the appropriate position)
 * @param Int number of characters after which wrapping should occur
 * @param Boolean definitely wrap after each interval (ignore whitespace)
 * @return String resulting (wrapped) string
 */
String.prototype.softwrap = function(interval, ignoreWhiteSpace) {
   return this.group(interval, "<wbr />", ignoreWhiteSpace);
}

/**
 * function calculates the md5 hash of a string
 * @return String md5 hash of the string
 */
String.prototype.md5 = function() {
   return Packages.helma.util.MD5Encoder.encode(this);
}

/**
 * function repeats a string passed as argument
 * @param Int amount of repetitions
 * @return String resulting string
 */
String.prototype.repeat = function(multiplier) {
   var result = new java.lang.StringBuffer();
   for (var i=0; i<multiplier; i++)
      result.append(this);
   return result.toString();
}

/**
 * function returns true if the string starts with
 * the string passed as argument
 * @param String string pattern to search for
 * @return Boolean true in case it matches the beginning
 *         of the string, false otherwise
 */
String.prototype.startsWith = function(str, offset) {
   var javaObj = new java.lang.String(this);
   if (offset != null)
      return javaObj.startsWith(str, offset);
   return javaObj.startsWith(str);
}

/**
 * function returns true if the string ends with
 * the string passed as argument
 * @param String string pattern to search for
 * @return Boolean true in case it matches the end of
 *         the string, false otherwise
 */
String.prototype.endsWith = function(str) {
   var javaObj = new java.lang.String(this);
   return javaObj.endsWith(str);
}

/**
 * transforms the first n characters of a string to uppercase
 * @param Number amount of characters to transform
 * @return String the resulting string
 */
String.prototype.capitalize = function(limit) {
   if (limit == null)
      limit = 1;
   var head = this.substring(0, limit);
   var tail = this.substring(limit, this.length);
   return head.toUpperCase() + tail.toLowerCase();
}

/**
 * transforms the first n characters of each
 * word in a string to uppercase
 * @return String the resulting string
 */
String.prototype.titleize = function() {
   var parts = this.split(" ");
   var result = new java.lang.StringBuffer();
   for (var i in parts) {
      result.append(parts[i].capitalize());
      if (i < parts.length-1)
         result.append(" ");
   }
   return result.toString();
}

/**
 * fills a string with another string up to a desired length
 * @param String the filling string
 * @param Number the desired length of the resulting string
 * @param Number the direction which the string will be padded in:
 *               -1: left   0: both (balance)  1: right
 *               (you can use the constants String.LEFT,
 *                String.BALANCE and String.RIGHT here as well.)
 * @return String the resulting string
 */
String.prototype.pad = function(str, len, dir) {
   if (str  == null || len == null)
      return this;
   var diff = len - this.length;
   if (diff == 0)
      return this;
   var left, right = 0;
   if (dir == null || dir == String.RIGHT)
      right = diff;
   else if (dir == String.LEFT)
      left = diff;
   else if (dir == String.BALANCE) {
      right = Math.round(diff / 2);
      left = diff - right;
   }
   var result = new java.lang.StringBuffer();
   for (var i=0; i<left; i++)
      result.append(str);
   result.append(this);
   for (var i=0; i<right; i++)
      result.append(str);
   return result;
}

/**
 * function returns true if a string contains the string
 * passed as argument
 * @param String string to search for
 * @param Int Position to start search
 * @param Boolean
 */
String.prototype.contains = function(str, fromIndex) {
   if (this.indexOf(str, fromIndex ? fromIndex : 0) > -1)
      return true;
   return false;
}

/**
 * function compares a string with the one passed as argument
 * using diff
 * @param String String to compare against String object value
 * @return Object Array containing one JS object for each line
 *                with the following properties:
 *                .num Line number
 *                .value String line if unchanged
 *                .deleted Obj Array containing deleted lines
 *                .inserted Obj Array containing added lines
 */
String.prototype.diff = function(mod) {
   // split both strings into arrays of lines
   var orig = this.split(/\r\n|\r|\n/);
   var mod = mod.split(/\r\n|\r|\n/);
   // create the Diff object
   var diff = new Packages.helma.util.Diff(orig, mod);
   // get the diff.
   var d = diff.diff();
   if (!d)
      return null;

   var result = new Array();
   for (var i=0; i<mod.length; i++) {
      var line = result[i];
      if (!line) {
         line = new Object();
         line.num = (i+1);
         result[i] = line;
      }
      if (d && i == d.line1) {
         if (d.deleted) {
            var del = new Array();
            for (var j=d.line0; j<d.line0+d.deleted; j++)
               del[del.length] = orig[j];
            line.deleted = del;
         }
         if (d.inserted) {
            var ins = new Array();
            for (var j=d.line1; j<d.line1+d.inserted; j++)
               ins[ins.length] = mod[j];
            line.inserted = ins;
         }
         i = d.line1 + d.inserted -1;
         d = d.link;
      } else {
         line.value = mod[i];
      }
   }
   return result;
}

/**
 * remove preceding and trailing spaces
 */
String.prototype.trim = function () {
   var s = new java.lang.String(this);
   return String(s.trim());
}

/**
 * helper function for clip(), head() and tail() methods
 * @param Number desired length of string
 * @param String pre-/suffix to be pre-/appended to shortened string
 * @param Boolean definitely cut after limit (ignore whitespace)
 * @return Object containing head and tail properties
 */
String.prototype.dissect = function(limit, clipping, ignoreWhiteSpace) {
   var str = this;
   var result = {head: str, tail: ""};
   if (!limit)
      return result;
   result.head = str = stripTags(str);
   if (str.length <= limit)
      return result;
   var cut = (ignoreWhiteSpace == true) ? limit : str.indexOf(" ", limit);
   if (cut < 0)
      return result;
   result.head = str.substring(0, cut).trim();
   if (result.head) {
      result.tail = str.substring(cut).trim();
      if (result.tail) {
         if (clipping == null)
            clipping = "...";
         result.head += clipping;
         result.tail = clipping + result.tail;
      }
   }
   return result;
}

/**
 * get the head of a string
 * @see String.prototype.dissect(), String.prototype.clip()
 */
String.prototype.head = function(limit, clipping, ignoreWhiteSpace) {
   return this.dissect(limit, clipping, ignoreWhiteSpace).head;
}

/**
 * get the tail of a string
 * @see String.prototype.dissect()
 */
String.prototype.tail = function(limit, clipping, ignoreWhiteSpace) {
   return this.dissect(limit, clipping, ignoreWhiteSpace).tail;
}

/**
 * function inserts a string every number of characters
 * @param Int number of characters after which insertion should take place
 * @param String string to be inserted
 * @param Boolean definitely insert at each interval position
 * @return String resulting string
 */
String.prototype.group = function(interval, str, ignoreWhiteSpace) {
   if (!str || this.length < interval)
      return this;
   var buf = new java.lang.StringBuffer();
   for (var i=0; i<this.length; i=i+interval) {
      var strPart = this.substring(i, i+interval);
      buf.append(strPart);
      if (ignoreWhiteSpace == true || (strPart.length == interval && strPart.indexOf(" ") < 0))
         buf.append(str);
   }
   return buf.toString();
}

/**
 * insert a <br /> every number of chars of a string
 * (ie. hardwrap the string at the appropriate position)
 * @param Number number of chars after wich wrapping should occur
 * @return String the wrapped string
 */
String.prototype.hardwrap = function(interval) {
   return this.group(interval, "<br />", true);
}

/**
 * insert a <wbr /> every number of chars of a string
 * (ie. softwrap the string at the appropriate position)
 * @param Int number of characters after which wrapping should occur
 * @param Boolean definitely wrap after each interval (ignore whitespace)
 * @return String resulting (wrapped) string
 */
String.prototype.softwrap = function(interval, ignoreWhiteSpace) {
   return this.group(interval, "<wbr />", ignoreWhiteSpace);
}

/**
 * replace all linebreaks and optionally all w/br tags
 * @param Boolean flag indicating if html tags should be replaced
 * @param String replacement for the linebreaks / html tags
 * @return String the unwrapped string
 */
String.prototype.unwrap = function(removeTags, replacement) {
   if (replacement == null)
      replacement = "";
   var str = this.replace(/[\n|\r]/g, replacement);
   if (removeTags)
      str = str.replace(/<[w]?br *\/?>/g, replacement);
   return str;   
}

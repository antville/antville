Html = {
   version: "1.1",

   toString: function() {
      return "[HtmlLibrary Object]";
   },

   getVersion: function() {
      return this.version;
   },

   /**
    * returns a rendered arbitrary x/html element
    * @param name String containing the element's name
    * @param String String to prepend to rendered element
    * @param String String to append to rendered element
    * @param attr [optional] Object containing the element's attributes as properties
    * @return Object StringBuffer object containing the rendered markup part
    */
   renderMarkupPart: function(name, start, end, attr) {
      res.write(start);
      res.write(name);
      if (attr) {
         for (var i in attr) {
            if (attr[i] == null)
               continue;
            res.write(" ");
            res.write(i);
            res.write("=\"");
            res.write(attr[i]);
            res.write("\"");
         }
      }
      res.write(end);
   },
   
   /**
    * Writes an arbitrary x/html element ("begin tag")
    * directly to response
    * @param name String containing the element's name
    * @param attr Object containing the element's attributes as properties
    */
   openTag: function(name, attr) {
      this.renderMarkupPart(name, "<", ">", attr);
   },

   /**
    * Returns an arbitrary x/html element ("begin tag")
    * @param name String containing the element's name
    * @param attr Object containing the element's attributes as properties
    * @return String rendered markup element
    */
   openTagAsString: function(name, attr) {
      res.pushStringBuffer();
      this.renderMarkupPart(name, "<", ">", attr);
      return res.popStringBuffer();
   },

   /**
    * Writes an arbitray x/html element ("end tag")
    * directly to response
    * @param name String containing the element's name
    */
   closeTag: function(name) {
      this.renderMarkupPart(name, "</", ">", null);
   },

   /**
    * Returns an arbitray x/html element ("end tag")
    * @param name String containing the element's name
    * @return String rendered markup element
    */
   closeTagAsString: function(name) {
      res.pushStringBuffer();
      this.renderMarkupPart(name, "</", ">", null);
      return res.popStringBuffer();
   },

   /**
    * Outputs an arbitrary empty x/html element ("contentless tag")
    * @param name String containing the element's name
    * @param attr Object containing the element's attributes as properties
    */
   tag: function(name, attr) {
      this.renderMarkupPart(name, "<", " />", attr);
   },

   /**
    * returns an arbitrary empty x/html element ("contentless tag")
    * @param name String containing the element's name
    * @param attr Object containing the element's attributes as properties
    */
   tagAsString: function(name, attr) {
      res.pushStringBuffer();
      this.renderMarkupPart(name, "<", " />", attr);
      return res.popStringBuffer();
   },

   /**
    * write a complete link tag directly to response
    * @param String URL to link to
    * @param String Text to use as link
    */
   link: function(url, text) {
      this.openTag("a", {href: url});
      res.write(text);
      this.closeTag("a");
      return;
   },


   /**
    * return a complete link tag as string
    * @param String URL to link to
    * @param String Text to use as link
    * @return String rendered Link
    */
   linkAsString: function(url, text) {
      res.pushStringBuffer();
      this.openTag("a", {href: url});
      res.write(text);
      this.closeTag("a");
      return res.popStringBuffer();
   },


   /**
    * writes an html link element directly to response
    * @param String URL to use in a-tag
    */
   openLink: function(url) {
      this.openTag("a", {href: url});
      return;
   },
   
   /**
    * returns a rendered open link element
    * @param String URL to use in a-tag
    * @return String rendered element
    */
   openLinkAsString: function(url) {
      return this.openTagAsString("a", {href: url});
   },
   
   /**
    * write a closing link element directly to response
    */
   closeLink: function() {
      this.closeTag("a");
      return;
   },
   
   /**
    * returns a rendered closing link element
    * @return String rendered element
    */
   closeLinkAsString: function() {
      return this.closeTagAsString("a");
   },

   /**
    * renders a hidden input field
    * @param attr Object contains the element's attributes
    */
   hidden: function(attr) {
      if (!attr)
         var attr = new Object();
      attr.type = "hidden";
      attr.value = attr.value ? encodeForm(attr.value) : null;
      this.tag("input", attr);
      return;
   },

   /**
    * renders an input type text
    * @param attr Object contains the element's attributes
    */
   input: function(attr) {
      if (!attr)
         var attr = new Object();
      attr.type = "text";
      if (!attr.size)
         attr.size = 20;
      attr.value = attr.value ? encodeForm(attr.value) : "";
      this.tag("input", attr);
      return;
   },

   /**
    * renders a textarea
    * @param attr Object contains the element's attributes
    */
   textArea: function(attr) {
      if (!attr)
         var attr = new Object();
      if (!attr.cols)
         attr.cols = 40;
      if (!attr.rows)
         attr.rows = 5;
      if (!attr.wrap)
         attr.wrap = "virtual";
      var value = attr.value ? encodeForm(attr.value) : "";
      delete attr.value;
      this.openTag("textarea", attr);
      res.write(value);
      this.closeTag("textarea");
      return;
   },

   /**
    * renders an input type password
    * @param attr Object contains the element's attributes
    */
   password: function(attr) {
      if (!attr)
         var attr = new Object();
      attr.type = "password";
      if (!attr.size)
         attr.size = 20;
      this.tag("input", attr);
      return;
   },

   /**
    * function renders an input type file
    * @param attr Object contains the element's attributes
    */
   file: function(attr) {
      if (!attr)
         var attr = new Object();
      attr.type = "file";
      this.tag("input", attr);
      return;
   },

   /**
    * renders an input of type checkbox
    * @param attr Object contains the element's attributes
    */
   checkBox: function(attr) {
      if (!attr)
         var attr = new Object();
      attr.type = "checkbox";
      if (parseInt(attr.value) == 1 || attr.value == true)
         attr.checked = "checked";
      if (!attr.value)
         attr.value = "1";
      this.tag("input", attr);
      return;
   },

   /**
    * renders an input of type radio
    * @param attr Object contains the element's attributes
    */
   radioButton: function(attr) {
      if (!attr)
         var attr = new Object();
      attr.type = "radio";
      if (attr.value == attr.selectedValue)
         attr.checked = "checked";
      else
         delete attr.checked;
      delete attr.selectedValue;
      this.tag("input", attr);
      return;
   },

   /**
    * renders a submit-button
    * @param attr Object contains the element's attributes
    */
   submit: function(attr) {
      if (!attr)
         var attr = new Object();
      attr.type = "submit";
      if (!attr.name)
         attr.name = attr.type;
      attr.value = attr.value ? encodeForm(attr.value) : attr.type;
      this.tag("input", attr);
      return;  
   },

   /**
    * renders an input of type "button"
    * @param attr Object contains the element's attributes
    */
   button: function(attr) {
      if (!attr)
         var attr = new Object();
      attr.type = "button";
      if (!attr.name)
         attr.name = attr.type;
      attr.value = attr.value ? encodeForm(attr.value) : attr.type;
      this.tag("input", attr);
      return;  
   },

   /**
    * renders a drop down box directly to response
    * @param String Name of the select tag
    * @param Array options - an array of strings,
    *                      - an array with several objects which
    *                        have to contain the properties .value
    *                        and .display
    *                      - an array in an array:
    *                        [0] is the value, [1] is for display
    * @param String value that should be preselected
    * @param String String to display as first option (without a value)
    */
   dropDown: function(name, options, selectedIndex, firstoption) {
      this.openTag("select", {name: name, size: 1});
      res.write("\n ");

      if (firstoption) {
         this.openTag("option", {value: ""});
         res.write(firstoption);
         this.closeTag("option");
         res.write("\n ");
      }
      for (var i in options) {
         var attr = new Object();
         var display = "";
         if ((options[i] instanceof Array) && options[i].length > 0) {
            // option is an array
            attr.value = options[i][0];
            display = options[i][1];
         } else if (options[i].value && options[i].display) {
            // option is an object
            attr.value = options[i].value;
            display = options[i].display;
         } else {
            // assume option is a string
            attr.value = i;
            display = options[i];
         }
         if (attr.value == selectedIndex)
            attr.selected = "selected";
         this.openTag("option", attr);
         res.write(display);
         this.closeTag("option");
         res.write("\n ");
      }
      this.closeTag("select");
      res.write("\n ");
   },


   /**
    * function tries to check if the color contains just hex-characters
    * if so, it returns the color-definition prefixed with a '#'
    * otherwise it assumes the color is a named one
    */
   colorAsString: function(c) {
      if (c) {
         var nonhex = new RegExp("[^0-9,a-f]");
         nonhex.ignoreCase = true;
         var found = c.match(nonhex);
         if (!found) {
            while (c.length < 6)
               c = "0" + c;
            // color-string contains just hex-characters, so we prefix it with '#'
            return "#" + c;
         }
      }
      return c;
   },


   /**
    * renders a color as hex or named string
    */
   color: function(c) {
      res.write(this.colorAsString(c));
      return;
   },

   /**
    *  Renders an image map from an Array
    *  each array contains an object describing the parameters
    *  for the area of the image-map
    *  @param String name = name of the image map
    *  @param String areas = array containing image-map objects
    *                        if property alt doesnt't exist, it will be set ""
    *                        if property shape doesnt't exist, it will be set "rect"
    */
   map: function(name, areas) {
      this.openTag("map", {name: name});
      for (var i in areas) {
         if (!areas[i].alt)
            areas[i].alt = "";
         if (!areas[i].shape)
            areas[i].shape = "rect";
         this.openTag("area", areas[i]);
      }
      this.closeTag("map");
      return;
   },

   /**
    * render a form-tag (open)
    * @param String prototype of handler object used to construct action URL
    * @param String name of action to point to
    * @param Obj optional attributes to render
    */
   form: function(handlerProto, action, attr) {
      if (!action || !handlerProto)
         return;
      if (!attr)
         var attr = new Object();
      var handler = path[handlerProto];
      if (handler)
         attr.action = handler.href(action);
      this.openTag("form", attr);
   }
}

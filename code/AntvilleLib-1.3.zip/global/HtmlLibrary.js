Html = {
   toString: function() {
      return "[Antville HtmlLibrary]";
   },

   /**
    * returns a rendered arbitrary x/html element
    * @param name String containing the element's name
    * @param String String to prepend to rendered element
    * @param String String to append to rendered element
    * @param attr [optional] Object containing the element's attributes as properties
    * @return Object StringBuffer object containing the rendered markup part
    */
   renderMarkupPart: function(name, start, end, attr) {
      res.write(start);
      res.write(name);
      if (attr) {
         for (var i in attr) {
            if (attr[i] == null)
               continue;
            res.write(" ");
            res.write(i);
            res.write("=\"");
            res.write(attr[i]);
            res.write("\"");
         }
      }
      res.write(end);
   },
   
   /**
    * Writes an arbitrary x/html element ("begin tag")
    * directly to response
    * @param name String containing the element's name
    * @param attr Object containing the element's attributes as properties
    */
   openTag: function(name, attr) {
      this.renderMarkupPart(name, "<", ">", attr);
   },

   /**
    * Returns an arbitrary x/html element ("begin tag")
    * @param name String containing the element's name
    * @param attr Object containing the element's attributes as properties
    * @return String rendered markup element
    */
   openTagAsString: function(name, attr) {
      res.push();
      this.renderMarkupPart(name, "<", ">", attr);
      return res.pop();
   },

   /**
    * Writes an arbitray x/html element ("end tag")
    * directly to response
    * @param name String containing the element's name
    */
   closeTag: function(name) {
      this.renderMarkupPart(name, "</", ">", null);
   },

   /**
    * Returns an arbitray x/html element ("end tag")
    * @param name String containing the element's name
    * @return String rendered markup element
    */
   closeTagAsString: function(name) {
      res.push();
      this.renderMarkupPart(name, "</", ">", null);
      return res.pop();
   },

   /**
    * Outputs an arbitrary empty x/html element ("contentless tag")
    * @param name String containing the element's name
    * @param attr Object containing the element's attributes as properties
    */
   tag: function(name, attr) {
      this.renderMarkupPart(name, "<", " />", attr);
   },

   /**
    * returns an arbitrary empty x/html element ("contentless tag")
    * @param name String containing the element's name
    * @param attr Object containing the element's attributes as properties
    */
   tagAsString: function(name, attr) {
      res.push();
      this.renderMarkupPart(name, "<", " />", attr);
      return res.pop();
   },

   /**
    * write a complete link tag directly to response
    * @param attr Object containing the element's attributes as properties,
    *     value is used as link-display
    */
   link: function(attr, text) {
      if (!attr) {
         res.write("[Html.link: insufficient arguments]");
         return;
      }
      this.openTag("a", attr);
      res.write(text);
      this.closeTag("a");
      return;
   },


   /**
    * return a complete link tag as string
    * @param attr Object containing the element's attributes as properties,
    *     value is used as link-display
    * @return String rendered Link
    */
   linkAsString: function(attr, text) {
      res.push();
      this.link(attr, text);
      return res.pop();
   },


   /**
    * writes an html link element directly to response
    * @param attr Object containing the element's attributes as properties
    */
   openLink: function(attr) {
      this.openTag("a", attr);
      return;
   },
   
   /**
    * returns a rendered open link element
    * @param attr Object containing the element's attributes as properties
    * @return String rendered element
    */
   openLinkAsString: function(attr) {
      return this.openTagAsString("a", attr);
   },
   
   /**
    * write a closing link element directly to response
    */
   closeLink: function() {
      this.closeTag("a");
      return;
   },
   
   /**
    * returns a rendered closing link element
    * @return String rendered element
    */
   closeLinkAsString: function() {
      return this.closeTagAsString("a");
   },

   /**
    * renders a hidden input field
    * @param attr Object contains the element's attributes
    */
   hidden: function(attr) {
      if (!attr) {
         res.write("[Html.hidden: insufficient arguments]");
         return;
      }
      attr.type = "hidden";
      attr.value = attr.value ? encodeForm(attr.value) : null;
      this.tag("input", attr);
      return;
   },

   /**
    * renders a hidden input field, returning it as string
    * @param attr Object contains the element's attributes
    */
   hiddenAsString: function(attr) {
      res.push();
      this.hidden(attr);
      return res.pop();
   },

   /**
    * renders an input type text
    * @param attr Object contains the element's attributes
    */
   input: function(attr) {
      if (!attr) {
         res.write("[Html.input: insufficient arguments]");
         return;
      }
      attr.type = "text";
      if (!attr.size)
         attr.size = 20;
      attr.value = attr.value ? encodeForm(attr.value) : "";
      this.tag("input", attr);
      return;
   },

   /**
    * renders an input type text, returning it as string
    * @param attr Object contains the element's attributes
    */
   inputAsString: function(attr) {
      res.push();
      this.input(attr);
      return res.pop();
   },

   /**
    * renders a table
    * @param headers an array containing table headers
    * @param data a 2 dimensional array containing the table data
    * @param attr attribute holder
    */
   table: function(headers, data, attr) {
      if (!attr) {
         res.write("[Html.table: insufficient arguments]");
         return;
      }
      if (!attr.trHead) attr.trHead = attr.tr;
      if (!attr.trEven) attr.trEven = attr.tr;
      if (!attr.trOdd)  attr.trOdd = attr.tr;
      if (!attr.tdEven) attr.tdEven = attr.td;
      if (!attr.tdOdd)  attr.tdOdd = attr.td;
      if (!attr.thEven) attr.thEven = attr.th;
      if (!attr.thOdd)  attr.thOdd = attr.th;
      this.openTag("table", attr.table);
      if (headers) {
         this.openTag("tr", attr.trHead);
         for (var i in headers) {
            var evenOdd = i % 2 == 0 ? "Even" : "Odd";
            this.openTag("th", attr["th"+evenOdd]);
            res.write(headers[i]);
            this.closeTag("th");
         }
         this.closeTag("tr");
      }
      for (var i in data) {
         var evenOdd = i % 2 == 0 ? "Even" : "Odd";
         this.openTag("tr", attr["tr"+evenOdd]);
         for (var j in data[i]) {
            var evenOddCell = j % 2 == 0 ? "Even" : "Odd";
            this.openTag("td", attr["td"+evenOddCell]);
            res.write(data[i][j]);
            this.closeTag("td");
         }
         this.closeTag("tr");
      }
      this.closeTag("table");
   },

   /**
    * renders a table, returning it as string
    * @param headers an array containing table headers
    * @param data a 2 dimensional array containing the table data
    * @param attr attribute holder
    */
   tableAsString: function(headers, data, attr) {
      res.push();
      this.table(headers, data, attr);
      return res.pop();
   },

   /**
    * renders a textarea
    * @param Object containing the element's attributes
    */
   textArea: function(param) {
      if (!param) {
         res.write("[Html.textArea: insufficient arguments]");
         return;
      }
      var attr = Object.clone(param);
      if (!attr.wrap)
         attr.wrap = "virtual";
      var value = attr.value ? encodeForm(attr.value) : "";
      delete attr.value;
      this.openTag("textarea", attr);
      res.write(value);
      this.closeTag("textarea");
      return;
   },

   /**
    * renders a textarea, returning it as string
    * @param attr Object contains the element's attributes
    */
   textAreaAsString: function(attr) {
      res.push();
      this.textArea(attr);
      return res.pop();
   },

   /**
    * renders an input type password
    * @param attr Object contains the element's attributes
    */
   password: function(attr) {
      if (!attr) {
         res.write("[Html.password: insufficient arguments]");
         return;
      }
      attr.type = "password";
      if (!attr.size)
         attr.size = 20;
      this.tag("input", attr);
      return;
   },

   /**
    * renders an input type password, returning it as string
    * @param attr Object contains the element's attributes
    */
   passwordAsString: function(attr) {
      res.push();
      this.password(attr);
      return res.pop();
   },

   /**
    * function renders an input type file
    * @param attr Object contains the element's attributes
    */
   file: function(attr) {
      if (!attr) {
         res.write("[Html.file: insufficient arguments]");
         return;
      }
      attr.type = "file";
      this.tag("input", attr);
      return;
   },

   /**
    * function renders an input type file, returning it as string
    * @param attr Object contains the element's attributes
    */
   fileAsString: function(attr) {
      res.push();
      this.file(attr);
      return res.pop();
   },

   /**
    * renders an input of type checkbox
    * @param attr Object contains the element's attributes
    */
   checkBox: function(param) {
      if (!param) {
         res.write("[Html.checkBox: insufficient arguments]");
         return;
      }
      var attr = Object.clone(param);
      attr.type = "checkbox";
      if (attr.selectedValue != null) {
         if (param.value == param.selectedValue)
            attr.checked = "checked";
         else
            delete attr.checked;
         delete attr.selectedValue;
      }
      this.tag("input", attr);
      return;
   },

   /**
    * renders an input of type checkbox, returning it as string
    * @param attr Object contains the element's attributes
    */
   checkBoxAsString: function(attr) {
      res.push();
      this.checkBox(attr);
      return res.pop();
   },

   /**
    * renders an input of type radio
    * @param attr Object contains the element's attributes
    */
   radioButton: function(param) {
      if (!param) {
         res.write("[Html.radioButton: insufficient arguments]");
         return;
      }
      var attr = Object.clone(param);
      attr.type = "radio";
      if (attr.selectedValue != null) {
         if (attr.value == attr.selectedValue)
            attr.checked = "checked";
         else
            delete attr.checked;
         delete attr.selectedValue;
      }
      this.tag("input", attr);
      return;
   },

   /**
    * renders an input of type radio, returning it as string
    * @param attr Object contains the element's attributes
    */
   radioButtonAsString: function(attr) {
      res.push();
      this.radioButton(attr);
      return res.pop();
   },

   /**
    * renders a submit-button
    * @param attr Object contains the element's attributes
    */
   submit: function(attr) {
      if (!attr) {
         res.write("[Html.submit: insufficient arguments]");
         return;
      }
      attr.type = "submit";
      if (!attr.name)
         attr.name = attr.type;
      attr.value = attr.value ? encodeForm(attr.value) : attr.type;
      this.tag("input", attr);
      return;  
   },

   /**
    * renders an input of type submit, returning it as string
    * @param attr Object contains the element's attributes
    */
   submitAsString: function(attr) {
      res.push();
      this.submit(attr);
      return res.pop();
   },

   /**
    * renders an input of type "button"
    * @param attr Object contains the element's attributes
    */
   button: function(attr) {
      if (!attr) {
         res.write("[Html.button: insufficient arguments]");
         return;
      }
      attr.type = "button";
      if (!attr.name)
         attr.name = attr.type;
      attr.value = attr.value ? encodeForm(attr.value) : attr.type;
      this.tag("input", attr);
      return;  
   },

   /**
    * renders an input of type button, returning it as string
    * @param attr Object contains the element's attributes
    */
   buttonAsString: function(attr) {
      res.push();
      this.button(attr);
      return res.pop();
   },

   /**
    * renders a drop down box directly to response
    * @param attr Object containing the element's attributes
    * @param options Array - an array of strings,
    *                      - an array with several objects which
    *                        have to contain the properties .value
    *                        and .display
    *                      - an array in an array:
    *                        [0] is the value, [1] is for display
    * @param selectedValue String that should be preselected
    * @param firstOption String to display as first option (without a value)
    */
   dropDown: function(attr, options, selectedValue, firstOption) {
      if (!attr) {
         res.write("[Html.dropDown: insufficient arguments]");
         return;
      }
      if (!attr.size)
         attr.size = 1;
      this.openTag("select", attr);
      res.write("\n ");
      if (firstOption) {
         this.openTag("option", {value: ""});
         res.write(firstOption);
         this.closeTag("option");
         res.write("\n ");
      }
      for (var i in options) {
         var attr = new Object();
         var display = "";
         if ((options[i] instanceof Array) && options[i].length > 0) {
            // option is an array
            attr.value = options[i][0];
            display = options[i][1];
         } else if (options[i].value && options[i].display) {
            // option is an object
            attr.value = options[i].value;
            display = options[i].display;
         } else {
            // assume option is a string
            attr.value = i;
            display = options[i];
         }
         if (attr.value == selectedValue)
            attr.selected = "selected";
         this.openTag("option", attr);
         res.write(display);
         this.closeTag("option");
         res.write("\n ");
      }
      this.closeTag("select");
      res.write("\n ");
      return;
   },

   /**
    * renders a dropdown box, returning it as string
    * @param attr Object containing the element's attributes
    * @param options Array - an array of strings,
    *                      - an array with several objects which
    *                        have to contain the properties .value
    *                        and .display
    *                      - an array in an array:
    *                        [0] is the value, [1] is for display
    * @param selectedValue String that should be preselected
    * @param firstOption String to display as first option (without a value)
    */
   dropDownAsString: function(attr, options, selectedValue, firstOption) {
      res.push();
      this.dropDown(attr, options, selectedValue, firstOption);
      return res.pop();
   },

   /**
    * function tries to check if the color contains just hex-characters
    * if so, it returns the color-definition prefixed with a '#'
    * otherwise it assumes the color is a named one
    */
   colorAsString: function(c) {
      if (c) {
         var nonhex = new RegExp("[^0-9,a-f]");
         nonhex.ignoreCase = true;
         var found = c.match(nonhex);
         if (!found) {
            while (c.length < 6)
               c = "0" + c;
            // color-string contains just hex-characters, so we prefix it with '#'
            return "#" + c;
         }
      }
      return c;
   },


   /**
    * renders a color as hex or named string
    */
   color: function(c) {
      res.write(this.colorAsString(c));
      return;
   },

   /**
    *  Renders an image map from an Array
    *  each array contains an object describing the parameters
    *  for the area of the image-map
    *  @param String name = name of the image map
    *  @param String areas = array containing image-map objects
    *                        if property alt doesnt't exist, it will be set ""
    *                        if property shape doesnt't exist, it will be set "rect"
    */
   map: function(name, areas) {
      this.openTag("map", {name: name});
      for (var i in areas) {
         if (!areas[i].alt)
            areas[i].alt = "";
         if (!areas[i].shape)
            areas[i].shape = "rect";
         this.openTag("area", areas[i]);
      }
      this.closeTag("map");
      return;
   },

   /**
    *  Renders an image map from an Array, returning it as string
    *  each array contains an object describing the parameters
    *  for the area of the image-map
    *  @param String name = name of the image map
    *  @param String areas = array containing image-map objects
    *                        if property alt doesnt't exist, it will be set ""
    *                        if property shape doesnt't exist, it will be set "rect"
    */
   mapAsString: function(name, areas) {
      res.push();
      this.map(name, areas);
      return res.pop();
   },

   /**
    * render a form-tag (open)
    * @param String prototype of handler object used to construct action URL
    * @param String name of action to point to
    * @param Obj optional attributes to render
    */
   form: function(attr) {
      this.openTag("form", attr);
      return;
   },

   /**
    * render a form-tag (open), returning it as string
    * @param String prototype of handler object used to construct action URL
    * @param String name of action to point to
    * @param Obj optional attributes to render
    */
   formAsString: function(attr) {
      res.push();
      this.form(attr);
      return res.pop();
   }

}

Color = function(R,G,B) {
   if (arguments.length == 1) {
      var re = /rgb ?\( ?([0-9^,]*), ?([0-9^,]*), ?([0-9^ \)]*) ?\)/;
      var result = R.match(re);
      if (result) {
         this.rgb = [
            parseInt(result[1], 10),
            parseInt(result[2], 10),
            parseInt(result[3], 10)
         ];
      } else {
         if (R.indexOf("#") == 0)
            R = R.substring(1);
         this.rgb = Color.hexToRGB(R);
         this.hex = R;
      }
   } else
      this.rgb = [R,G,B];
   return this;
}

Color.prototype.valueOf = function() {
   return this.rgb;
}

Color.prototype.toString = function() {
   if (this.hex == null)
      this.hex = Color.RGBtoHex(this.rgb);
   return this.hex;
}

Color.hexToRGB = function(str) {
   var rgb = [];
   for (var i=0; i<str.length; i+=2) {
      var hex = str.substring(i, i+2);
      rgb.push(parseInt(hex, 16));
   }
   return rgb;
}

Color.RGBtoHex = function(rgb) {
   var hex = new java.lang.StringBuffer();
   for (var i in rgb)
      hex.append(rgb[i].toString(16).pad("0", 2, String.LEFT));
   return hex.toString();
}

Color.getColorPicker = function(size) {
   res.contentType = "text/plain";
   var brightness = new Array();
   if (size == null)
      size = 12;
   var step = 1/(size/3)/3;
   var i = 0;
   res.write("this.brightness = [");
   for (var L=.0; L<=1.0; L+=step) {
      brightness[i] = new Array();
      res.write("\n   [");
      for (var H=.0; H<=1.0; H+=step) {
         for (var S=.0; S<=1.0; S+=step) {
            var color = Color.HSLtoRGB(H,S,L);
            var hexColor = color.toString();
            brightness[i][brightness[i].length] = hexColor;
            res.write('"'+hexColor+'"');
            if (S<1.0)
               res.write(",");
         }
        if (H<1.0)
           res.write(",");
      }
      res.write("]");
      if (i<size)
         res.write(",");
      i++;
   }
   res.write("\n];");
   return;
}

// i adapted the HSLtoRGB conversion method from
// http://www1.tip.nl/~t876506/ColorDesign.html#hr
// thanks! [ts]
Color.HSLtoRGB = function(H,S,L) {
   function H1(H,S,L) {
      var R = 1;
      var G = 6*H;
      var B = 0;
      G = G*S + 1 - S;
      B = B*S + 1 - S;
      R = R*L; G = G*L;
      B = B*L;
      return [R,G,B];
   }
   
   function H2(H,S,L) {
      var R = 1-6*(H - 1/6);
      var G = 1;
      var B = 0;
      R = R*S + 1 - S;
      B = B*S + 1 - S
      R = R*L; G = G*L;
      B = B*L
      return [R,G,B];
   }
   
   function H3(H,S,L) {
      var R = 0;
      var G = 1;
      var B = 6*(H - 1/3);
      R = R*S + 1 - S;
      B = B*S + 1 - S;
      R = R*L;
      G = G*L;
      B = B*L
      return [R,G,B];
   }
   
   function H4(H,S,L) {
      var R = 0;
      var G = 1-6*(H - 1/2);
      var B = 1;
      R = R*S + 1 - S;
      G = G*S + 1 - S;
      R = R*L; G = G*L;
      B = B*L;
      return [R,G,B];
   }
   
   function H5(H,S,L) {
      var R = 6*(H - 2/3);
      var G = 0;
      var B = 1;
      R = R*S + 1 - S;
      G = G*S + 1 - S;
      R = R*L; G = G*L;
      B = B*L;
      return [R,G,B];
   }
   
   function H6(H,S,L) {
      var R = 1;
      var G = 0;
      var B = 1-6*(H - 5/6);
      G = G*S + 1 - S;
      B = B*S + 1 - S;
      R = R*L; G = G*L;
      B = B*L;
      return [R,G,B];
   }
   
   // H  [0-1] is divided into 6 equal sectors.
   // From within each sector the proper conversion function is called.
   var rgb;
   if (H < 1/6)
      rgb = H1(H,S,L);
   else if (H < 1/3)
      rgb = H2(H,S,L);
   else if (H < 1/2)
      rgb = H3(H,S,L);
   else if (H < 2/3)
      rgb = H4(H,S,L);
   else if (H < 5/6)
      rgb = H5(H,S,L);
   else
      rgb = H6(H,S,L);
   return new Color(
      Math.round(rgb[0]*255),
      Math.round(rgb[1]*255),
      Math.round(rgb[2]*255)
   );
}

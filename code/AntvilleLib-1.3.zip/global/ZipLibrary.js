ZipLib = {
   version: "0.1",

   toString: function() {
      return "[ZipLibrary Object]";
   },

   getVersion: function() {
      return this.version;
   },

   /**
    * extract all files in a ByteArray passed as argument
    * and return them as result Array
    * @param Object ByteArray containing the data of the .zip File
    * @return Object Array containing JS objects for each entry
    *                (see ZipLib._createResultObject for description)
    */
   extractAll: function(zipData) {
      var zInStream = new java.util.zip.ZipInputStream(new java.io.ByteArrayInputStream(zipData));
      var result = new ZipResult();

      var entry;
      while ((entry = zInStream.getNextEntry()) != null) {
         var eParam = ZipLib._createResultObject(entry);
         if (eParam.size == -1)
            eParam.size = 16384;
         var bos = new java.io.ByteArrayOutputStream(eParam.size);
         var buf = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 8192);
         var count;
         while ((count = zInStream.read(buf)) != -1)
            bos.write(buf, 0, count);
         eParam.data = bos.toByteArray();
         eParam.size = bos.size();
         result.add(eParam);
      }
      zInStream.close();
      return result;

      /* works fine
      var zInStream = new java.util.zip.ZipInputStream(new java.io.ByteArrayInputStream(zipData));
      var result = new Array();
      var entry;
      while ((entry = zInStream.getNextEntry()) != null) {
         var eParam = ZipLib._createResultObject(entry);
         if (eParam.size == -1)
            eParam.size = 16384;
         var bos = new java.io.ByteArrayOutputStream(eParam.size);
         var buf = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 8192);
         var count;
         while ((count = zInStream.read(buf)) != -1)
            bos.write(buf, 0, count);
         eParam.data = bos.toByteArray();
         eParam.size = bos.size();
         result.push(eParam);
      }
      zInStream.close();
      return result;
      */
   },

   /**
    * internal helper function that creates a JS object
    * based on a ZipEntry object
    * @param Object java.util.zip.ZipEntry Object
    * @return Object JS object containing the following properties:
    *                .name (String) name of the entry
    *                .size (Int) decompressed size of the entry in bytes
    *                .time (Date) last modification timestamp of the entry or null
    *                .isDirectory (Boolean) true in case entry is a directory, false otherwise
    *                .data (ByteArray) ByteArray containing the data of the entry
    */
   _createResultObject: function(entry) {
      return { name: entry.getName(),
               size: entry.getSize(),
               time: entry.getTime() ? new Date(entry.getTime()) : null,
               isDirectory: entry.isDirectory(),
               data: null
             };
   },

   /**
    * internal helper function that extracts the data of a file
    * in a .zip archive. If a destination Path is given it
    * writes the extracted data directly to disk using the
    * name of the ZipEntry Object, otherwise it returns the
    * byte array containing the extracted data
    * @param Object java.util.zip.ZipFile Object
    * @param Object java.util.zip.ZipEntry Object to extract
    * @param String destination path to extract ZipEntry Object to
    * @return Object ByteArray containing the data of the ZipEntry
    */
   _extractEntry: function(zFile, entry, destPath) {
      var size = entry.getSize();
      if (entry.isDirectory() || size <= 0)
         return null;

      var zInStream = new java.io.BufferedInputStream(zFile.getInputStream(entry));
      var buf = new java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, size);
      zInStream.read(buf, 0, size);
      zInStream.close();

      if (!destPath) {
         // no filesystem destination given, so return
         // the byte array containing the extracted data
         return buf;
      }
      // extract the file to the given path
      var dest = new java.io.File(destPath, entry.getName());
      if (entry.isDirectory())
         dest.mkdirs();
      else if (buf) {
         if (!dest.getParentFile().exists())
            dest.getParentFile().mkdirs();
         try {
            var outStream = new java.io.BufferedOutputStream(new java.io.FileOutputStream(dest));
            outStream.write(buf, 0, size);
         } finally {
            outStream.close();
         }
      }
      return null;
   },

   /**
    * internal function for adding a single file to the .zip archive
    * @param Object java.util.zip.ZipOutputStream
    * @param Object java.io.File object that should be added
    * @param Int compression-level (0-9)
    * @param String path of the directory in the archive to which the
    *               file should be added (optional)
    */
   _addFile: function(zOutStream, f, level, pathPrefix) {
      var fInStream = new java.io.BufferedInputStream(new java.io.FileInputStream(f), f.length());
      buf = new java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, f.length());
      fInStream.read(buf, 0, f.length());

      var name = new java.lang.StringBuffer();
      if (pathPrefix) {
         // append clean pathPrefix to name buffer
         var st = new java.util.StringTokenizer(pathPrefix, "\\/");
         while (st.hasMoreTokens()) {
            name.append(st.nextToken());
            name.append(java.io.File.separator);
         }
      }
      name.append(f.getName());
      var entry = new java.util.zip.ZipEntry(name.toString());
      entry.setSize(f.length());
      entry.setTime(f.lastModified());
      zOutStream.setLevel(level);
      zOutStream.putNextEntry(entry);
      zOutStream.write(buf, 0, buf.length);
      zOutStream.closeEntry();
      fInStream.close();
      return true;
   }
}



/**
 * constructor function for Zip Objects
 * @param either
 *        - (Object) a File object
 *        - (Object) an instance of java.io.File
 *        - (String) the path to the zip file
 */
function Zip(file) {
   // basic properties
   this.bOutStream = new java.io.ByteArrayOutputStream();
   this.zOutStream = new java.util.zip.ZipOutputStream(this.bOutStream);
   this.file = null;
   if (file) {
      if (file instanceof File)
         f = new java.io.File(file.getAbsolutePath());
      else if (!(file instanceof java.io.File))
         f = new java.io.File(file);
      if (!f.exists())
         throw new Error("Zip file " + f.getAbsolutePath() + " is not existing");
      this.file = f;
   }

   this.toString = function() {
      if (this.file)
         return "[Zip Object " + this.file.getAbsolutePath() + "]";
      else
         return "[Zip Object]";
   };

   /**
    * returns an array containing the entries of a .zip file as objects
    * (see ZipLib._createResultObject for description)
    * @param Object File object representing the .zip file on disk
    * @return Object result object
    */
   this.list = function() {
      var result = new ZipResult();
      var zFile = new java.util.zip.ZipFile(this.file);
      var entries = zFile.entries();
      while (entries.hasMoreElements())
         result.add(ZipLib._createResultObject(entries.nextElement()));
      zFile.close();
      return result;
   };

   /**
    * extract a single file from a .zip archive
    * if a destination path is given it directly writes
    * the extracted file to disk
    * @param Object File object representing the .zip file on disk
    * @param String Name of the file to extract
    * @param String (optional) destination path to write file to
    * @return Object JS Object (see ZipLib._createResultObject for description)
    */
   this.extract = function(name, destPath) {
      var zFile = new java.util.zip.ZipFile(this.file);
      var entry = zFile.getEntry(name);
      if (!entry)
         return null;
      var result = ZipLib._createResultObject(entry);
      result.data = ZipLib._extractEntry(zFile, entry, destPath);
      zFile.close();
      return result;
   };

   /**
    * extract all files in a .zip archive
    * if a destination path is given it directly writes
    * the extracted files to disk (preserves directory structure
    * of .zip archive if existing!)
    * @param String (optional) destination path to write file to
    * @return Object Array containing JS objects for each entry
    *                (see ZipLib._createResultObject for description)
    */
   this.extractAll = function(destPath) {
      var result = new ZipResult();
      var zFile = new java.util.zip.ZipFile(this.file);
      var entries = zFile.entries();
      while (entries.hasMoreElements()) {
         var entry = entries.nextElement();
         var obj = ZipLib._createResultObject(entry);
         obj.data = ZipLib._extractEntry(zFile, entry, destPath);
         result.add(obj);
      }
      zFile.close();
      return result;
   };

   /**
    * add a single file or a whole directory (recursive!) to the .zip archive
    * @param either
    *        - (Object) a File object
    *        - (Object) an instance of java.io.File
    *        - (String) the path to the file that should be added
    * @param Int Level to use for compression (default: 9 = best compression)
    * @param String name of the directory in the archive into which the
    *               file should be added (optional)
    * @return Boolean true
    */
   this.add = function (f, level, pathPrefix) {
      // parse arguments
      if (f instanceof File)
         f = new java.io.File(f.getAbsolutePath());
      else if (!(f instanceof java.io.File))
         f = new java.io.File(f);

      if (!level)
         var level = 9;
      // evaluate arguments
      if (arguments.length == 2) {
         if (typeof arguments[1] == "string") {
            pathPrefix = arguments[1];
            level = 9;
         } else {
            level = arguments[1];
            pathPrefix = null;
         }
      }
      if (f.isDirectory()) {
         var filePath = f.getAbsolutePath();
         // add a whole directory to the zip file (recursive!)
         var files = FileLib.listRecursive(f.getAbsolutePath());
         for (var i in files) {
            var file = new java.io.File(files[i]);
            if (!file.isDirectory()) {
               var p = file.getPath().substring(filePath.length, file.getParent().length);
               if (pathPrefix)
                  p = pathPrefix + p;
               ZipLib._addFile(this.zOutStream, file, level, p);
            }
         }
      } else
         ZipLib._addFile(this.zOutStream, f, level, pathPrefix);
      return true;
   };

   /**
    * add a new entry to the zip file
    * @param Object byte[] containing the data to add
    * @param String name of the file to add
    * @param Int compression level (0-9, default: 9)
    * @return Boolean true
    */
   this.addData = function(buf, name) {
      var entry = new java.util.zip.ZipEntry(name);
      entry.setSize(buf.length);
      entry.setTime(new Date());
      this.zOutStream.setLevel(9);
      this.zOutStream.putNextEntry(entry);
      this.zOutStream.write(buf, 0, buf.length);
      this.zOutStream.closeEntry();
      return true;
   };

   /**
    * close the ZipOutputStream and return the
    * data of the ByteArrayOutputStream
    * @return Object ByteArray containing the binary data of the zip file
    */
   this.close = function() {
      this.zOutStream.close();
      return this.bOutStream.toByteArray();
   };

   /**
    * save the archive by closing the output stream
    * @param String path (including the name) to save the zip file to
    * @return Boolean true
    */
   this.save = function(dest) {
      if (!dest)
         throw new Error("no destination for ZipFile given");
      // first of all, close the ZipOutputStream
      this.zOutStream.close();
      var destFile = new java.io.File(dest);
      try {
         var outStream = new java.io.FileOutputStream(destFile);
         this.bOutStream.writeTo(outStream);
      } finally {
         outStream.close();
      }
      return true;
   };
}

/**
 * constructor function for ZipResult Objects
 */
function ZipResult() {
   this.toc = new Array();
   this.files = new Object();
   this.add = function(eParam) {
      // add the file to the table of contents array
      this.toc.push(eParam);
      // plus add it to the files tree
      var re = /[\\\/]/;
      var arr = eParam.name.split(re);
      var cnt = 0;
      var curr = this.files;
      var propName;
      while (cnt < arr.length-1) {
         propName = arr[cnt++];
         if (!curr[propName])
            curr[propName] = new Object();
         curr = curr[propName];
      }
      curr[arr[cnt]] = eParam;
   };
}

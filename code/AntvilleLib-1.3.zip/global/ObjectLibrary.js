Object.clone = function(obj) {
   var clone = {};
   for (var p in obj)
      clone[p] = obj[p];
   return clone;
}

// DEPRECATED
// keep this for a while for b/w compatibility...
ObjectLib = {
   version: "0.2",
   getVersion: function() {
      return this.version;
   },
   clone: Object.clone
}


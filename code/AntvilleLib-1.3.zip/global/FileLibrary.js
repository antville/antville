File.separator = java.io.File.separator;

/**
 * construct a file object and return it
 */
File.get = function(path, name) {
   return name ? new File(path, name) : new File(path);
}

/**
 * check if a file or directory already exists
 * @param String path to directory or file
 * @param String name of file (optional)
 * @return File-Object or null
 */
File.exists = function(path, name) {
   return File.get(path, name).exists();
}

/**
 * function checks if a file or directory is writeable
 * @param String path to directory or file
 * @param String name of file (optional)
 * @return File-Object or null
 */
File.isWriteable = function(path, name) {
   return File.get(path, name).canWrite();
}

/**
 * function creates a directory if it doesn't exist
 * @param String path to directory
 * @return File-Object or null
 */
File.mkdir = function(path) {
	var f = File.get(path);
   if (!f.exists())
   	return f.mkdir() ? f : null;
   else
      return f;
}

/**
 * recursivly deletes a directory
 * @param String path to directory
 * @returns true/false
 */
File.removeDir = function(path) {
   var dir = File.get(path);
   if (!dir.isDirectory())
      return false;
   var arr = dir.list();
   for (var i=0; i<arr.length; i++) {
      var f = File.get(dir, arr[i]);
      if (f.isDirectory())
         File.removeDir(f);
      else
         f.remove();
   }
   dir.remove();
   return true;
}

/**
 * recursivly lists all files below a given directory
 * @param String path to directory
 * @returns array containing the absolute paths of the files
 */
File.listRecursive = function(path, result) {
   var dir = File.get(path);
   if (!dir.isDirectory())
      return false;
   if (result == null)
      var result = [];
   var arr = dir.list();
   for (var i=0; i<arr.length; i++) {
      var f = new File(dir, arr[i]);
      if (f.isDirectory())
         File.listRecursive(f, result);
      else
         result.push(f.getAbsolutePath());
   }
   result.push(dir.getAbsolutePath());
   return result;
}

/**
 * function makes a copy of a file over partitions
 * @param String full path of the original file
 * @param String full path of the new file
 */
File.hardCopy = function(src, dest) {
   var inStream = new java.io.BufferedInputStream(new java.io.FileInputStream(src));
   var outStream = new java.io.BufferedOutputStream(new java.io.FileOutputStream(dest));
   var buffer = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 4096);
   var bytesRead = 0;
   while ((bytesRead = inStream.read(buffer, 0, buffer.length)) != -1) {
      outStream.write(buffer, 0, bytesRead);
   }
   outStream.flush();
   inStream.close();
   outStream.close();
   return true;
}

/**
 * function moves a file to a new destination directory
 * @param String full path of the original file
 * @param String full path of the new file
 * @return Boolean true in case file could be moved, false otherwise
 */
File.move = function(src, dest) {
   // instead of using the standard File method renameTo()
   // do a hardCopy and then remove the source file. This way
   // file locking shouldn't be an issue
   File.hardCopy(src, dest);
   // remove the source file
   var f = File.get(src);
   f.remove();
   return true;
}


/**
 * wrapper to also allow all file objects
 * to call the hardCopy method
 * @see File.hardCopy
 */
File.prototype.hardCopy = function(dest) {
   return File.hardCopy(this.getPath(), dest);
}

/**
 * wrapper to also allow all file objects
 * to call the move method
 * @see File.move
 */
File.prototype.move = function(dest) {
   return File.move(this.getPath(), dest);
}

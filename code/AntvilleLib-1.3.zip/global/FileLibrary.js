FileLib = {
   version: "0.7",

   toString: function() {
      return "[FileLibrary Object]";
   },

   getVersion: function() {
      return this.version;
   },

   /**
    * construct a file object and return it
    */
   get: function (path, name) {
      return name ? new File(path, name) : new File(path);
   },

   /**
    * check if a file or directory already exists
    * @param String path to directory or file
    * @param String name of file (optional)
    * @return File-Object or null
    */
   exists: function(path, name) {
      return this.get(path, name).exists();
   },

   /**
    * function checks if a file or directory is writeable
    * @param String path to directory or file
    * @param String name of file (optional)
    * @return File-Object or null
    */
   isWriteable: function(path, name) {
      return this.get(path, name).canWrite();
   },

   /**
    * function creates a directory if it doesn't exist
    * @param String path to directory
    * @return File-Object or null
    */
   mkdir: function(path) {
   	var f = this.get(path);
      if (!f.exists())
      	return f.mkdir() ? f : null;
      else
         return f;
   },

   /**
    * recursivly deletes a directory
    * @param String path to directory
    * @returns true/false
    */
   removeDir: function(path) {
      var dir = this.get(path);
      if (!dir.isDirectory())
         return false;
      var arr = dir.list();
      for (var i=0; i<arr.length; i++) {
         var f = this.get(dir, arr[i]);
         if (f.isDirectory())
            this.removeDir(f);
         else
            f.remove();
      }
      dir.remove();
      return true;
   },

   /**
    * recursivly lists all files below a given directory
    * @param String path to directory
    * @returns array containing the absolute paths of the files
    */
   listRecursive: function(path, result) {
      var dir = this.get(path);
      if (!dir.isDirectory())
         return false;
      if (result == null)
         var result = new Array();
      var arr = dir.list();
      for (var i=0; i<arr.length; i++) {
         var f = new File (dir, arr[i]);
         if (f.isDirectory())
            this.listRecursive(f, result);
         else
            result[result.length] = f.getAbsolutePath();
      }
      result[result.length] = dir.getAbsolutePath();
      return result;
   },

   /**
    * function makes a copy of a file over partitions
    * @param String full path of the original file
    * @param String full path of the new file
    */
   hardCopy: function(orig, dest) {
      var inStream = new java.io.BufferedInputStream(new java.io.FileInputStream(orig));
      var outStream = new java.io.BufferedOutputStream(new java.io.FileOutputStream(dest));
      var buffer = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 4096);
      var bytesRead = 0;
      while ((bytesRead = inStream.read(buffer, 0, buffer.length)) != -1) {
         outStream.write(buffer, 0, bytesRead);
      }
      outStream.flush();
      inStream.close();
      outStream.close();
      return  true;
   },

   /**
    * function moves a file to a new destination directory
    * @param String full path of the original file
    * @param String full path of the new file
    * @return Boolean true in case file could be moved, false otherwise
    */
   move: function(orig, dest) {
      // instead of using the standard File method renameTo()
      // do a hardCopy and then remove the source file. This way
      // file locking shouldn't be an issue
      this.hardCopy(orig.dest);
      // remove the source file
      var f = this.get(orig);
      f.remove();
      return true;
   }
}

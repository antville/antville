function skin_macro(param) {
   if (param.name)
      renderSkin(param.name);
   return;
}

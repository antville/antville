Date.ONESECOND = 1000;
Date.ONEMINUTE = 60 * Date.ONESECOND;
Date.ONEHOUR   = 60 * Date.ONEMINUTE;
Date.ONEDAY    = 24 * Date.ONEHOUR;
Date.ONEWEEK   =  7 * Date.ONEDAY;
Date.ONEMONTH  = 30 * Date.ONEDAY;
Date.ISOFORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";

/**
 * format a Date to a string
 * @param String Format pattern
 * @param Object Java Locale Object (optional)
 * @param Object Java TimeZone Object (optional)
 * @return String formatted Date
 */
Date.prototype.format = function (fmt, locale, timezone) {
   // date format parsing is quite expensive, but date formats
   // are not thread safe, so what we do is to cache them per request
   // in the response object. FIXME: is this comment up-to-date?
   if (!fmt)
      return this.toString();
   var sdf = res.data["_dateformat"];
   if (!sdf) {
      sdf = locale ? new java.text.SimpleDateFormat(fmt, locale)
            : new java.text.SimpleDateFormat(fmt);
   } else if (fmt != sdf.toPattern()) {
      sdf.applyPattern(fmt);
   }
   if (timezone && sdf.getTimeZone() != timezone)
      sdf.setTimeZone(timezone);
   return sdf.format(this);
}


/** 
 * set the date/time to UTC by subtracting
 * the timezone offset
 */ 
Date.prototype.toUTC = function() {
   this.setMinutes(this.getMinutes() + this.getTimezoneOffset());
}


/** 
 * set the date/time to local time by adding
 * the timezone offset
 */ 
Date.prototype.toLocalTime = function() {
   this.setMinutes(this.getMinutes() - this.getTimezoneOffset());
}

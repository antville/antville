Date.ONESECOND = 1000;
Date.ONEMINUTE = 60 * Date.ONESECOND;
Date.ONEHOUR   = 60 * Date.ONEMINUTE;
Date.ONEDAY    = 24 * Date.ONEHOUR;
Date.ONEWEEK   =  7 * Date.ONEDAY;
Date.ONEMONTH  = 30 * Date.ONEDAY;
Date.ISOFORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";

/**
 * format a Date to a string
 * @param String Format pattern
 * @param Object Java Locale Object (optional)
 * @param Object Java TimeZone Object (optional)
 * @return String formatted Date
 */
Date.prototype.format = function (format, locale, timezone) {
   // date format parsing is quite expensive, but date formats
   // are not thread safe, so what we do is to cache them per request
   // in the response object.
   // 2004-02-18: also cache locale and check if cache matches 
   // the current arguments. (ts)
   if (!format)
      return this.toString();
   var sdf = res.data._dateformat;
   // we have to check for req because otherwise we get unpredictable
   // results in dates formatted from within the scheduler
   if (!sdf || !req || res.data._locale != locale) {
      sdf = locale ? new java.text.SimpleDateFormat(format, locale)
         : new java.text.SimpleDateFormat(format);
      res.data._dateformat = sdf;
      res.data._locale = locale;
   } else if (format != sdf.toPattern())
      sdf.applyPattern(format);
   if (timezone && timezone != sdf.getTimeZone())
      sdf.setTimeZone(timezone);
   return sdf.format(this);
}


/** 
 * set the date/time to UTC by subtracting
 * the timezone offset
 */ 
Date.prototype.toUTC = function() {
   this.setMinutes(this.getMinutes() + this.getTimezoneOffset());
}


/** 
 * set the date/time to local time by adding
 * the timezone offset
 */ 
Date.prototype.toLocalTime = function() {
   this.setMinutes(this.getMinutes() - this.getTimezoneOffset());
}


/**
 * returns the difference between this and another
 * date object in milliseconds
 */
Date.prototype.diff = function(dateObj) {
   return this.getTime() - dateObj.getTime();
}


/**
 * format a Date to a string
 * @param String Format pattern
 * @param Object Java Locale Object (optional)
 * @param Object Java TimeZone Object (optional)
 * @return String formatted Date
 */
Date.prototype.format = function (fmt, locale, timezone) {
   // date format parsing is quite expensive, but date formats
   // are not thread safe, so what we do is to cache them per request
   // in the response object
   if (!fmt)
      return this.toString();
   var sdf = res.data["_dateformat"];
   if (!sdf) {
      sdf = locale ? new java.text.SimpleDateFormat(fmt, locale)
            : new java.text.SimpleDateFormat(fmt);
   } else if (fmt != sdf.toPattern()) {
      sdf.applyPattern(fmt);
   }
   if (timezone && sdf.getTimeZone() != timezone)
      sdf.setTimeZone(timezone);
   return sdf.format(this);
}


/** 
 * set the date/time to UTC by subtracting
 * the timezone offset
 */ 
Date.prototype.toUTC = function() {
   this.setMinutes(this.getMinutes() + this.getTimezoneOffset());
}


/** 
 * set the date/time to local time by adding
 * the timezone offset
 */ 
Date.prototype.toLocalTime = function() {
   this.setMinutes(this.getMinutes() - this.getTimezoneOffset());
}

function test_action() {
   var str = "12345 6789 012345 67890";
   var errors = [];

   if (str.clip(7) != "12345 6789...")
      errors.push("clip 1");
   if (str.clip(7, "xxx") != "12345 6789xxx")
      errors.push("clip 2");
   if (str.clip(7, "xxx", false) != "12345 6789xxx")
      errors.push("clip 3");
   if (str.clip(7, "xxx", true) != "12345 6xxx")
      errors.push("clip 4");

   if (str.tail(7) != "...012345 67890")
      errors.push("tail 1");
   if (str.tail(7, "xxx") != "xxx012345 67890")
      errors.push("tail 2");
   if (str.tail(7, "xxx", false) != "xxx012345 67890")
      errors.push("tail 3");
   if (str.tail(7, "xxx", true) != "xxx789 012345 67890")
      errors.push("tail 4");

   if (str.group(3, "x") != "123x45 678x9 0123x45 678x90")
      errors.push("group 1");
   if (str.group(3, "x", true) != "123x45 x678x9 0x123x45 x678x90x")
      errors.push("group 2");

   str = "12\n3<wbr>45<br>67\r8<wbr />90\n\r<br />123";
   if (str.unwrap() != "123<wbr>45<br>678<wbr />90<br />123")
      errors.push("unwrap 1");
   if (str.unwrap(true) != "1234567890123")
      errors.push("unwrap 1");

   if (String.join("12345", null, "xxx") != "12345")
      errors.push("join 1");
   if (String.join(null, "67890", "xxx") != "67890")
      errors.push("join 2");
   if (String.join("12345", "67890", "xxx") != "12345xxx67890")
      errors.push("join 3");

   if (String.random(10) .length != 10)
      errors.push("random 1");
   if (/[01lo]/g .test(String.random(10, 1)))
      errors.push("random 2");
   if (/[a-zA-Z]/g .test(String.random(10, 2)))
      errors.push("random 3");

   if (StringLib.random.length != String.random.length)
      errors.push("compat 1");
   if (ObjectLib.clone.length != Object.clone.length)
      errors.push("compat 2");

   var obj = {};
   for (var i in obj)
      errors.push("object " + i);
   obj.property = "value";
   var clone = Object.clone(obj);
   if (!clone.property)
      errors.push("object clone");
   res.debug(errors);
   return;
}

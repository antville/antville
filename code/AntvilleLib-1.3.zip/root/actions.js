/**
 * helper action for binary output of
 * the infamous invisible pixel GIF
 * @see pixel_gif_macro
 */
function pixel_gif_action() {
   res.contentType = "image/gif";
   res.writeBinary([71,73,70,56,57,97,2,0,2,0,-128,-1,0,-64,-64,-64,0,0,0,33,-7,4,1,0,0,0,0,44,0,0,0,0,1,0,1,0,64,2,2,68,1,0,59]);
   return;
}

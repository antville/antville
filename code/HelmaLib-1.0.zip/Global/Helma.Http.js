
/**
  * simple HttpClient featuring proxy support and credentials.
  * requires: Apache Jakarta HttpClient
  *
  * http://jakarta.apache.org/commons/httpclient
  */

try {
   void(Helma);
} catch (err) {
   Helma = {
      toString: function() {
         return "[Helma JavaScript Library]";
      }
   }
}


Helma.Http = {

   toString: function() {
      return "[HttpClientLibrary Object]";
   },

   getVersion: function() {
      return "1.0";
   },

   /**
     * function for easy access to apache-jakarta's HttpClient package.
     * runs a request with a proxy and auth-settings on a per request basis.
     * @param urlString url to get
     * @param proxyString proxy server in "proxy.host.tld:3128"-format, null if no proxy should be used.
     * @param credentials credentials object as created by HttpClient.getCredentials()
     * @returns string with content or null on error
     */
   getUrl: function(urlString, proxyString, credentials) {
      var thePackage = Packages.org.apache.commons.httpclient;
      // check for apache library
      try {
         var str = new thePackage.HttpConstants();
      } catch (anyError) {
         throw("HttpClient needs apache-httpclient.jar in lib/ext or application directory!");
      }

      // init the cache for httpclient-objects
      if (!app.data._http) {
         app.data._http = new HopObject();
      }
      var http = app.data._http;

      // init httpclient
      if (!http.client) {
         app.debug("httpclient", "constructing new HttpClient and MultiThreadedHttpConnectionManager");
         var conManager = new thePackage.MultiThreadedHttpConnectionManager();
         http.client = new thePackage.HttpClient(conManager);
         http.client.setTimeout(20000);
         http.client.setConnectionTimeout(20000);
         http.client.setHttpConnectionFactoryTimeout(5000);
      }

      // create httpclient-uri from string
      var uri = new thePackage.URI(urlString);

      // prepare the request method object
      var method    = new thePackage.methods.GetMethod(urlString);

      var theConfig = method.getHostConfiguration();
      if (proxyString) {
         theConfig.setProxy(this.getProxyHost(proxyString), this.getProxyPort(proxyString));
      }

      // if credentials are given, construct http-state object
      if (credentials) {
         var theState = new thePackage.HttpState();
         // set credentials for any realm on the current server
         theState.setCredentials(null, uri.getHost(), credentials);
      } else {
         var theState = null;
      }

      // now run the request
      app.debug("httpclient", "[HttpClient] - executing method " + method + " for " + urlString + ", total current requests = " + http.client.getHttpConnectionManager().getConnectionsInUse(theConfig));
      try {
         http.client.executeMethod(theConfig, method, theState);
         // convert result
         var str = method.getResponseBodyAsString();
         app.debug("httpclient", "[HttpClient] - fetched method " + method + ", total current requests = " + http.client.getHttpConnectionManager().getConnectionsInUse(theConfig));
         method.releaseConnection();
         app.debug("httpclient", "[HttpClient] - released connection for " + method + " and " + urlString + ", total current requests = " + http.client.getHttpConnectionManager().getConnectionsInUse(theConfig));
         return str;
      } catch (exception) {
         app.debug("httpclient", "[HttpClient] - error in method " + method + " for " + urlString + ", total current requests = " + http.client.getHttpConnectionManager().getConnectionsInUse(theConfig) + ", error = " + exception);
         method.releaseConnection();
         return null;
      }
   },

   /**
     * creates a credentials object for HttClient
     * @param str1 if two arguments are given, this is considered the username,
     *    if only one is supplied it is considered to be the prefix in app.properties
     * @param password
     * @returns credentials object or null if arguments are missing
     */
   getCredentials: function(str1, password) {
      if (password) {
         var username = str1;
      } else {
         var username = app.properties[str1 + "username"];
         var password = app.properties[str1 + "password"];
      }
      if(!username || username.trim()=="" || !password) {
         return null;
      }
      return new Packages.org.apache.commons.httpclient.UsernamePasswordCredentials(username, password);
   },

   /**
     * parse a proxy string like "proxy.host.tld:3128" and extract the hostname
     */
   getProxyHost: function (proxyString) {
      var pos = proxyString.indexOf(":");
      if (proxyString.indexOf(":"))  {
         return proxyString.substring(0,pos);
      }  else  {
         return proxyString;
      }
   },

   /**
     * parse a proxy string like "proxy.host.tld:3128" and extract the port number
     */
   getProxyPort: function (proxyString) {
      var pos = proxyString.indexOf(":");
      if (proxyString.indexOf(":"))  {
         return parseInt(proxyString.substring(pos+1));
      }  else  {
         return 80;
      }
   }

}


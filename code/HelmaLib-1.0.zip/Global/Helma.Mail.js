try {
   Helma = Helma;
} catch (err) {
   Helma = {
      toString: function() {
         return "[Helma JavaScript Library]";
      }
   }
}

Helma.Mail = function() {
   var OK         =  0;
   var SUBJECT    = 10;
   var TEXT       = 11;
   var MIMEPART   = 12;
   var TO         = 20;
   var CC         = 21;
   var BCC        = 22;
   var FROM       = 23;
   var REPLYTO    = 24;
   var SEND       = 30;

   var self = this;
   var errStr = "Error in Helma.Mail";

   var System              = java.lang.System;
   var Properties          = java.util.Properties;
   var IOException         = java.io.IOException;
   var Wrapper             = Packages.org.mozilla.javascript.Wrapper;
   var FileDataSource      = Packages.javax.activation.FileDataSource;
   var DataHandler         = Packages.javax.activation.DataHandler;
   var Address             = Packages.javax.mail.Address;
   var Message             = Packages.javax.mail.Message;
   var Multipart           = Packages.javax.mail.Multipart;
   var Session             = Packages.javax.mail.Session;
   var Transport           = Packages.javax.mail.Transport;
   var InternetAddress     = Packages.javax.mail.internet.InternetAddress;
   var AddressException    = Packages.javax.mail.internet.AddressException;
   var MimePart            = Packages.javax.mail.internet.MimePart;
   var MimeBodyPart        = Packages.javax.mail.internet.MimeBodyPart;
   var MimeMessage         = Packages.javax.mail.internet.MimeMessage;
   var MimeUtility         = Packages.javax.mail.internet.MimeUtility;
   var MimeMultipart       = Packages.javax.mail.internet.MimeMultipart;
   var MimePartDataSource  = Packages.javax.mail.internet.MimePartDataSource;

   var buffer, multipart;

   var props = new Properties();
   System.setProperty("mail.mime.charset",
      System.getProperty("mail.charset", "ISO-8859-15"));

   var host = getProperty("smtp");
   if (host != null) {
      props.put("mail.smtp.host", host);
   }

   var session = Session.getInstance(props);
   var message = new MimeMessage(session);

   var setStatus = function(status) {
      if (self.status === OK) {
         self.status = status;
      }
      return;
   };

   var getStatus = function() {
      return self.status;
   };

   var addRecipient = function(addstr, name, type) {
      if (addstr.indexOf("@") < 0) {
         throw new AddressException();
      }
      if (name != null) {
         var address = new InternetAddress(addstr, 
                       MimeUtility.encodeWord(name.toString()));
      } else {
         var address = new InternetAddress(addstr);
      }
      message.addRecipient(type, address);
      return;
   };

   this.status = OK;
 
   this.setFrom = function(addstr, name) {
      try {
         if (addstr.indexOf("@") < 0) {
            throw new AddressException();
         }
         if (name != null) {
            var address = new InternetAddress(addstr, 
                          MimeUtility.encodeWord(name.toString()));
         } else {
            var address = new InternetAddress(addstr);
         }
         message.setFrom(address);
      } catch (mx) {
         res.debug(errStr + ".setFrom(): " + mx);
         setStatus(FROM);
      }
      return;
   };

   this.setReplyTo = function(addstr) {
      try {
         if (addstr.indexOf("@") < 0) {
            throw new AddressException();
         }
         var address = [new InternetAddress(addstr)];
         message.setReplyTo(address);
      } catch (mx) {
         res.debug(errStr + ".setReplyTo(): " + mx);
         setStatus(REPLYTO);
      }
      return;
   }

   this.setTo = function(addstr, name) {
      try {
         addRecipient(addstr, name, Message.RecipientType.TO);
      } catch (mx) {
         res.debug(errStr + ".setTo(): " + mx);
         setStatus(TO);
      }
      return;
   };

   this.addTo = function(addstr, name) {
      try {
         addRecipient(addstr, name, Message.RecipientType.TO);
      } catch (mx) {
         res.debug(errStr + ".addTo(): " + mx);
         setStatus(TO);
      }
      return;
   }

   this.addCC = function(addstr, name) {
      try {
         addRecipient(addstr, name, Message.RecipientType.CC);
      } catch (mx) {
         res.debug(errStr + ".addCC(): " + mx);
         setStatus(CC);
      }
      return;
   }

   this.addBCC = function(addstr, name) {
      try {
         addRecipient(addstr, name, Message.RecipientType.BCC);
      } catch (mx) {
         res.debug(errStr + ".addBCC(): " + mx);
         setStatus(BCC);
      }
      return;
   }

   this.setSubject = function(subject) {
      if (!subject) {
         return;
      }
      try {
         message.setSubject(MimeUtility.encodeWord(subject.toString()));
      } catch (mx) {
         res.debug(errStr + ".setSubject(): " + mx);
         setStatus(SUBJECT);
      }
      return;
   };

   this.setText = function(text) {
      if (text) {
         buffer = new java.lang.StringBuffer(text);
      }
      return;
   };

   this.addText = function(text) {
      if (buffer == null) {
         buffer = new java.lang.StringBuffer(text);
      } else {
         buffer.append(text);
      }
      return;
   };

   this.addPart = function(obj, filename) {
      try {
         if (obj == null) {
            throw new IOException(errStr + ".addPart: method called with wrong number of arguments.");
         }
         if (multipart == null) {
            multipart = new MimeMultipart();
         }
         if (obj instanceof Wrapper) {
            obj = obj.unwrap();
         }

         var part = new MimeBodyPart();
         if (typeof obj == "string") {
            part.setContent(obj.toString(), "text/plain");
         } else if (obj instanceof File) {
            // FIXME: the following line did not work under windows:
            //var source = new FileDataSource(obj);
            var source = new FileDataSource(obj.getPath());
            part.setDataHandler(new DataHandler(source));
         } else if (obj instanceof MimePart) {
            var source = new MimePartDataSource(obj);
            part.setDataHandler(new DataHandler(source));
         }
         if (filename != null) {
            try {
               part.setFileName(filename.toString());
            } catch (x) {}
         } else if (obj instanceof File) {
            try {
               part.setFileName(obj.getName());
            } catch (x) {}
         }
         multipart.addBodyPart(part);
      } catch (mx) {
         res.debug(errStr + ".addPart(): " + mx);
         setStatus(MIMEPART);
      }
      return;
   }

   this.send = function() {
      if (this.status > OK) {
         res.debug(errStr + ".send(): Status is " + this.status);
         return;
      }
      try {
         if (buffer != null) {
            if (multipart != null) {
               var part = new MimeBodyPart();
               part.setContent(buffer.toString(), "text/plain");
               multipart.addBodyPart(part, 0);
               message.setContent(multipart);
            } else {
               message.setText(buffer.toString());
            }
         } else if (multipart != null) {
            message.setContent(multipart);
         } else {
            message.setText("");
         }
         Transport.send(message);
      } catch (mx) {
         res.debug(errStr + ".send(): " + mx);
         setStatus(SEND);
      }
      return;
   };

   return this;
}

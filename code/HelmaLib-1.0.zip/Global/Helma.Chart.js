try {
   void(Helma);
} catch (err) {
   Helma = {
      toString: function() {
         return "[Helma JavaScript Library]";
      }
   }
}

//
// chart package by tobi
// needs andy khan's java excel api: download jxl.jar at
// http://www.andykhan.com/jexcelapi/
//

Helma.Chart = function(fpath, prefix, sname) {
   var f = new java.io.File(fpath);
   if (!f)
      return;

   function getCellStyle(c) {
      if (!c)
         return;
      var result = new Object();
      var format = c.getCellFormat();
      var font = format.getFont();
      if (font.getBoldWeight() > 400)
         result.bold = true;
      result.italic = font.isItalic();
      result.wrap = format.getWrap();
      var type = c.getType();
      var align = format.getAlignment().getDescription();
      if (align == "right" || type == "Number" || type == "Date")
         result.align = "right";
      else if (align == "centre")
         result.align = "center";
      return result;
   }

   var workbook = Packages.jxl.Workbook.getWorkbook(f);
   var sheet = sname ? workbook.getSheet(sname) : workbook.getSheet(0);
   if (!sheet)
      return;

   prefix = prefix ? prefix + "_" : "chart_";

   this.render = function() {
      res.write('<table border="0" cellspacing="1" class="'+prefix+'table">\n');
   
      var rowBuf = new Array();
      var rows = sheet.getRows();
      var max = 0;
      for (var i=0; i<rows; i++) {
         var row = sheet.getRow(i);
         if (row.length > max)
            max = row.length;
         rowBuf[rowBuf.length] = row;
      }
   
      for (var i in rowBuf) {
         res.write('<tr class="'+prefix+'row">\n');
         for (var n=0; n<max; n++) {
            if (n < rowBuf[i].length) {
               var c = rowBuf[i][n];
               var str = c.getContents();
               if (str)
                  var style = getCellStyle(c);
            }
            res.write('<td class="'+prefix+'cell"');
            if (style) {
               if (!style.wrap)
                  res.write(' nowrap="nowrap"');
               if (style.align)
                  res.write(' align="'+style.align+'"');
               res.write(">");
               if (style.bold)
                  res.write("<b>");
               if (style.italic)
                  res.write("<i>");
            }
            else
               res.write(">");
            res.write(str);
            if (style) {
               if (style.italic)
                  res.write("</i>");
               if (style.bold)
                  res.write("</b>");
            }
            res.write('</td>\n');
         }
         res.write('</tr>\n');
      }
   
      res.write('</table>\n');
      workbook.close();
   };

   this.renderAsString = function() {
      res.push();
      this.render();
      return res.pop();
   };

   return this;
}


function chart_macro(param) {
  if (!param.name)
      return;
   var p = getPoolObj(param.name, "files");
   if (!p) // || (p.obj.mimetype.lastIndexOf("excel") != p.obj.mimetype.length-5))
      return;
   var fpath = getProperty("filePath") + p.obj.site.alias + "/" + p.obj.name;
   renderChart(fpath, param.style, param.sheet);
   return;
}

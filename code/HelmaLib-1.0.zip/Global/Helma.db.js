try {
   Helma = Helma;
} catch (err) {
   Helma = {
      toString: function() {
         return "[Helma JavaScript Library]";
      }
   }
}

Helma.db = {};

Helma.db.MYSQL = "mysql";
Helma.db.ORACLE = "oracle";

Helma.db.getProductName = function(connection) {
   return connection.getMetaData().getDatabaseProductName().toLowerCase();
};

Helma.db.isMySql = function(connection) {
   return Helma.db.getName(connection) == Helma.db.MYSQL;
};

Helma.db.isOracle = function(connection) {
   return Helma.db.getName(connection) == Helma.db.ORACLE;
};

Helma.db.getSource = function(driver, url, dbname, user, password) {
   var props = new Packages.helma.util.SystemProperties();
   props.put(dbname + ".url", url);
   props.put(dbname + ".driver", driver);
   if (user) {
      props.put(dbname + ".user", user);
      props.put(dbname + ".password", password);
   }
   return new Packages.helma.objectmodel.db.DbSource(dbname, props);
};

Helma.db.getConnection = function(driver, url, dbname, user, password) {
   var dbSource = Helma.db.getSource(driver, url, dbname, user, password);
   return new Packages.helma.scripting.rhino.extensions.DatabaseObject(dbSource);
};

Helma.db.getSqlConnection = function(driver, url, dbname, user, password) {
   var dbSource = Helma.db.getSource(driver, url, dbname, user, password);
   return dbSource.getConnection();
};

Helma.db.getResultObject = function(sqlConn, sqlQuery) {
   var statement = sqlConn.createStatement();
   var resultSet = statement.executeQuery(sqlQuery);
   var metaData = resultSet.getMetaData();
   var max = metaData.getColumnCount();
   var result = [];
   while (resultSet.next()) {
      var row = {}
      for (var i=1; i<=max; i+=1)
         row[metaData.getColumnName(i)] = resultSet.getString(i);
      result.push(row);
   }
   return result;
};

Helma.db.getMySqlConnection = function(host, dbname, user, password, port) {
   port = port ? ":" + port : "";
   var driver = "org.gjt.mm.mysql.Driver";
   var url = "jdbc:mysql://" + host + port + "/" + dbname;
   return Helma.db.getConnection(driver, url, dbname, user, password);
};

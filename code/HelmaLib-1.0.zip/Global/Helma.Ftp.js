try {
   void(Helma);
} catch (err) {
   Helma = {
      toString: function() {
         return "[Helma JavaScript Library]";
      }
   }
}

Helma.Ftp = function(server) {
   var OK = 0;
   var LOGIN = 10;
   var LOGOUT = 11;
   var BINARY = 20;
   var ASCII = 21;
   var ACTIVE = 22;
   var PASSIVE = 23;
   var CD = 30;
   var LCD = 31;
   var PWD = 32;
   var DIR = 33;
   var MKDIR = 34;
   var RMDIR = 35;
   var GET = 40;
   var PUT = 41;
   var DELETE = 42;

   var FTP                    = Packages.com.oroinc.net.ftp.FTP;
   var FtpClient              = Packages.com.oroinc.net.ftp.FTPClient;
   var BufferedInputStream    = java.io.BufferedInputStream;
   var BufferedOutputStream   = java.io.BufferedOutputStream;
   var FileInputStream        = java.io.FileInputStream;
   var FileOutputStream       = java.io.FileOutputStream;
   var ByteArrayInputStream   = java.io.ByteArrayInputStream;
   var ByteArrayOutputStream  = java.io.ByteArrayOutputStream;

   var self = this;
   var errStr = "Error in Helma.Ftp";

   var ftpclient = new FtpClient();
   var localDir;

   var setStatus = function(status) {
      if (self.status === OK) {
         self.status = status;
      }
      return;
   };

   var getStatus = function() {
      return self.status;
   };

   this.server = server;
   this.status = OK;

   this.toString = function() {
      return "[JavaScript Ftp Object]";
   };

   this.login = function(username, password) {
      try {
         ftpclient.connect(this.server);
         ftpclient.login(username, password);
         return true;
      } catch (x) {
         res.debug(errStr + ".login : " + x);
         setStatus(LOGIN);
      }
      return false;
   };

   this.binary = function() {
      try {
         ftpclient.setFileType(FTP.BINARY_FILE_TYPE);
         return true;
      } catch (x) {
         res.debug(errStr + ".binary : " + x);
         setStatus(BINARY);
      }
      return false;
   };

   this.ascii = function() {
      try {
         ftpclient.setFileType(FTP.ASCII_FILE_TYPE);
         return true;
      } catch (x) {
         res.debug(errStr + ".ascii : " + x);
         setStatus(ASCII);
      }
      return false;
   };

   this.active = function() {
      try {
         ftpclient.enterLocalActiveMode();
         return true;
      } catch (x) {
         res.debug(errStr + ".active : " + x);
         setStatus(ACTIVE);
      }
      return false;
   }

   this.passive = function() {
      try {
         ftpclient.enterLocalPassiveMode();
         return true;
      } catch (x) {
         res.debug(errStr + ".passive : " + x);
         setStatus(PASSIVE);
      }
      return false;
   }

   this.pwd = function() {
      try {
         return ftpclient.printWorkingDirectory();
      } catch (x) {
         res.debug(errStr + ".pwd : " + x);
         setStatus(PWD);
      }
      return;
   };

   this.dir = function(path) {
      try {
         return ftpclient.listNames(path ? path : ".");
      } catch (x) {
         res.debug(errStr + ".dir : " + x);
         setStatus(DIR);
      }
      return;
   };

   this.mkdir = function(dir) {
      try {
         ftpclient.makeDirectory(dir);
         return true;
      } catch (x) {
         res.debug(errStr + ".mkdir : " + x);
         setStatus(MKDIR);
      }
      return false;
   };

   this.rmdir = function(dir) {
      try {
         ftpclient.removeDirectory(dir);
         return true;
      } catch(x) {
         res.debug(errStr + ".rmdir : " + x);
         setStatus(RMDIR);
      }
      return false;
   };

   this.cd = function(path) {
      try {
         ftpclient.changeWorkingDirectory(path);
         return true;
      } catch (x) {
         res.debug(errStr + ".cd : " + x);
         setStatus(CD);
      }
      return false;
   };

   this.lcd = function(dir) {
      try {
         localDir = new File(dir);
         if (!localDir.exists()) {
            localDir.mkdir();
            return true;
         }
      } catch (x) {
         res.debug(errStr + ".lcd : " + x);
         setStatus(LCD);
      }
      return false;
   };

   this.putFile = function(localFile, remoteFile) {
      try {
         if (localFile instanceof File) {
            var f = localFile;
         } else if (typeof localFile == "string") {
            var f = (localDir == null) ? new File(localFile) : new File(localDir, localFile);
         }
         var stream = new BufferedInputStream(new FileInputStream(f.getPath()));
         if (!remoteFile) {
            remoteFile = f.getName();
         }
         ftpclient.storeFile(remoteFile, stream);
         stream.close();
         return true;
      } catch (x) {
         res.debug(errStr + ".putFile : " + x);
         setStatus(PUT);
      }
      return false;
   };

   this.putString = function(str, remoteFile) {
      try {
         // constructor for byte[] objects:
         // java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 2048);
         var bytes = new java.lang.String(str).getBytes();
         var stream = ByteArrayInputStream(bytes);
         ftpclient.storeFile(remoteFile, stream);
         return true;
      } catch (x) {
         res.debug(errStr + ".putString : " + x);
         setStatus(PUT);
      }
      return false;
   };

   this.getFile = function(remoteFile, localFile) {
      try {
         var f = (localDir == null) ? new File(localFile) : new File(localDir, localFile);
         var stream = new BufferedOutputStream(new FileOutputStream(f.getPath()));
         ftpclient.retrieveFile(remoteFile, stream);
         stream.close();
         return true;
      } catch (x) {
         res.debug(errStr + ".getFile : " + x);
         setStatus(GET);
      }
      return false;
   };

   this.getString = function(remoteFile) {
      try {
         var stream = ByteArrayOutputStream();
         ftpclient.retrieveFile(remoteFile, stream);
         return stream.toString();
      } catch (x) {
         res.debug(errStr + ".getString : " + x);
         setStatus(GET);
      }
      return;
   };

   this.deleteFile = function(remoteFile) {
      try {
         ftpclient.deleteFile(remoteFile);
         return true;
      } catch (x) {
         res.debug(errStr + ".deleteFile : " + x);
         setStatus(DELETE);
      }
      return false;
   };

   this.logout = function() {
      try {
         ftpclient.logout();
         ftpclient.disconnect();
         return true;
      } catch (x) {
         res.debug(errStr + ".logout : " + x);
         setStatus(LOGOUT);
      }
      return false;
   };

   return this;
}

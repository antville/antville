try {
   void(Helma);
} catch (err) {
   Helma = {
      toString: function() {
         return "[Helma JavaScript Library]";
      }
   }
}

/**
 * Object for adding Aspects (by roman porotnikov,
 * http://freeroller.net/comments/deep?anchor=aop_fun_with_javascript)
 *
 * Note: Each prototype that uses aspects must implement a method
 * onCodeUpdate() to prevent aspects being lost when the prototype
 * is re-compiled
 */
Helma.Aspects = {

   addBefore: function(obj, fname, before) {
      var oldFunc = obj[fname];
      obj[fname] = function() {
         return oldFunc.apply(this, before(arguments, oldFunc, this));
      }
      return;
   },

   addAfter: function(obj, fname, after) {
      var oldFunc = obj[fname];
      obj[fname] = function() {
         return after(oldFunc.apply(this, arguments), arguments, oldFunc, this);
      }
      return;
   },

   addAround: function(obj, fname, around) {
      var oldFunc = obj[fname];
      obj[fname] = function() {
         return around(arguments, oldFunc, this);
      }
      return;
   }

}
try {
   void(Helma);
} catch (err) {
   Helma = {
      toString: function() {
         return "[Helma JavaScript Library]";
      }
   }
}

Helma.Image = function(arg) {
   var generator = new Packages.helma.image.ImageGenerator();
   return generator.createImage(arg);
}

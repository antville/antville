try {
   Helma = Helma;
} catch (err) {
   Helma = {
      toString: function() {
         return "[Helma JavaScript Library]";
      }
   }
}

Helma.Image = function(arg) {
   // according to http://grazia.helma.org/pipermail/helma-dev/2004-June/001253.html
   var generator = Packages.helma.image.ImageGenerator.getInstance();
   return generator.createImage(arg);
}


Helma.Image.getInfo = function(arg) {
   if (arguments.length != 1) {
      throw new java.lang.IllegalArgumentException("Image.getInfo() expects one argument");
   }

   var inp, result;
   var info = new Packages.helma.image.ImageInfo();
   // FIXME: we need a byte object for comparison
   var b = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 1024);

   try {
      if (arg instanceof java.io.InputStream) {
         inp = new java.io.InputStream(arg);
      // FIXME: here comes a dirty hack to check for a byte array
      } else if (arg.getClass && arg.getClass() == b.getClass()) {
         inp = new java.io.ByteArrayInputStream(arg);
      } else if (arg instanceof java.io.File) {
         inp = new java.io.FileInputStream(arg);
      } else if (arg instanceof Helma.File) {
         inp = new java.io.FileInputStream(arg.getFile());
      } else if (typeof arg == "string") {
         var str = arg;
         // try to interpret argument as URL if it contains a colon,
         // otherwise or if URL is malformed interpret as file name.
         if (str.indexOf(":") > -1) {
            try {
               var url = new java.net.URL(str);
               inp = url.openStream();
            } catch (mux) {
               inp = new java.io.FileInputStream(str);
            }
         } else {
            inp = new java.io.FileInputStream(str);
         }
      }
      if (inp == null) {
         var msg = "Unrecognized argument in Image.getInfo(): ";
         msg += (arg == null ? "null" : arg.getClass().toString());
         throw new java.lang.IllegalArgumentException(msg);
      }
      info.setInput(inp);
      if (info.check()) {
         result = info;
      }
   } catch (e) {
      // do nothing, returns null later
   } finally {
      if (inp != null) {
         try {
            inp.close();
         } catch (e) {}
      }
   }

   return result;
}

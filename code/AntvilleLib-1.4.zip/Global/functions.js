// Pre-defining global Sort object
// (currently used by HopObject.loop_macro for adding sorting methods.)
Sorters = {};

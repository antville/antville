/**
 * factory to create functions for sorting objects in an array
 * @param String name of the field each object is compared with
 * @param Number order (ascending or descending)
 * @return Function ready for use in Array.prototype.sort
 */
Number.Sorter = function(field, order) {
   var isDesc = (order == Number.Sorter.DESC);
   res.push();
   res.write(isDesc ? "return b['" : "return a['");
   res.write(field);
   res.write("'] - ");
   res.write(isDesc ? "a['" : "b['");
   res.write(field);
   res.write("'];");
   return new Function("a", "b", res.pop());
};


Number.Sorter.ASC = 0;
Number.Sorter.DESC = 1;


/**
 * format a Number to a String
 * @param String Format pattern
 * @return String Number formatted to a String
 * FIXME: this might need some localisation
 */
Number.prototype.format = function(fmt) {
   var df = fmt ? new java.text.DecimalFormat(fmt)
            : new java.text.DecimalFormat("#,##0.00");
   return df.format(0+this);
};


/** 
 * return the percentage of a Number
 * according to a given total Number
 * @param Int Total
 * @param String Format Pattern
 * @return Int Percentage
 */
Number.prototype.toPercent = function(total, fmt) {
	var p = this / (total / 100);
   if (!fmt)
      return Math.round(p * 100) / 100;
   return p.format(fmt);
};

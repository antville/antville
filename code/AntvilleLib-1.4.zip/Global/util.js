var util = {}


/**
 * helper function to get an object derived from 
 * a primitive java class (e.g. Byte[])
 * @param String the name of the primitive class
 * @param Integer the initial length of the derived object
 * @return Object the resulting object
 */
util.getJavaPrimitive = function(name, len) {
   if (!name || !java.lang[name])
      return;
   if (!len)
      len = 1024;
   return java.lang.reflect.Array.newInstance(java.lang[name].TYPE, len);
};

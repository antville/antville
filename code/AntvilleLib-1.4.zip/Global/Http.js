var http = {};


http.toString = function() {
   return "[HTTP Library]";
};


/**
 * set a proxy
 */
http.setProxy = function(host, port) {
   var sys = java.lang.System.getProperties();
   if (host) {
      if (!port)
         port = "8080";
      else if (typeof port == "number")
         port = port.toString();
      app.log("Setting proxy " + host + ":" + port);
      sys.put("http.proxySet", "true");
      sys.put("http.proxyHost", host);
      sys.put("http.proxyPort", port);
   } else {
      sys.put("http.proxySet", "false");
      sys.put("http.proxyHost", "");
      sys.put("http.prodyPort", "");
   }
   return true;
};


/**
 * returns host and port if a proxy is set, false otherwise
 */
http.getProxy = function() {
   var sys = java.lang.System.getProperties();
   if (sys.get("http.proxySet") == "true")
      return sys.get("http.proxyHost") + ":" + sys.get("http.proxyPort");
   return false;
};


/**
 * retrieves a url via http request
 * @param String the url or uri
 * @param String either "GET" or "HEAD"
 * @param DateOrString optional date or e-tag
 * @param Object optional proxy.host and proxy.port settings
 * @return Object the result containing a proper url, 
 *                the https response code and message
 */
http.Request = function(method, url, opt, proxy) {
   if ((method != "GET") && (method != "HEAD"))
      return null;

   if (typeof url == "string") {
      var url = http.evalUrl(url);
      if (!url)
         return null;
   }

   if (proxy) {
      var socket = new java.net.InetSocketAddress(proxy.host, proxy.port);
      var proxy = new java.net.Proxy(java.net.Proxy.Type.HTTP, socket);
      var conn = url.openConnection(proxy);
   } else
      var conn = url.openConnection();

   conn.setAllowUserInteraction(false);
   conn.setRequestMethod(method);
   conn.setRequestProperty("User-Agent", "AntvilleLib http.Request");

   if (opt) {
      if (opt instanceof Date)
         conn.setIfModifiedSince(opt.getTime());
      else if ((typeof opt == "string") && (opt.length > 0))
         conn.setRequestProperty("If-None-Match", opt);
   }

   this.url = conn.getURL();
   this.code = conn.getResponseCode();
   this.message = conn.getResponseMessage();
   this.length = conn.getContentLength();
   this.contentType = conn.getContentType();
   var lastmod = conn.getLastModified();
   if (lastmod)
      this.lastModified = new Date(lastmod);
   this.eTag = conn.getHeaderField("ETag");

   if ((this.length != 0) && (this.code != 304)) {
      var body = new java.io.ByteArrayOutputStream();
      var input = new java.io.BufferedInputStream(conn.getInputStream());
      var b = util.getJavaPrimitive("Byte");
      var str;
      while ((str = input.read(b)) > -1) {
         body.write(b, 0, str);
      }
      input.close();
      this.content = body.toString();
      this.length = this.content.length;
   }

   conn.disconnect();
   return this;
};


/**
 * retrieves a url via http get request
 * @param String the url or uri
 * @param DateOrString optional date or e-tag
 * @param Object optional proxy.host and proxy.port settings
 * @return Object the result containing a proper url, 
 *                the https response code and message
 */
http.get = function(url, opt, proxy) {
   return new http.Request("GET", url, opt);
};


/**
 * retrieves a url via http head request
 * @param String the url or uri
 * @param DateOrString optional date or e-tag
 * @param Object optional proxy.host and proxy.port settings
 * @return Object the result containing a proper url, 
 *                the https response code and message
 */
http.ping = function(url, opt, proxy) {
   return new http.Request("HEAD", url, opt);
};


/**
 * removes trailing slash from and evaluates a url
 * @param String the url or uri string
 * @return Object the result with error and result properties
 */
http.evalUrl = function(url) {
   while (url.endsWith("/"))
      url = url.substring(0, url.length - 1);
   try {
      return new java.net.URL(url);
   } catch (err) {
      return null;
   }
};


// FIXME: this is deprecated, only kept
// for backwards-compatibility reaons
var Http = http;

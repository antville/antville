// FIXME: this object will be obsolete, soon
// (currently deprecated.)
var Java = {};

Java.getPrimitive = function() {
   return util.getJavaPrimitive.apply(this);
};

/**
 * return the first index position of a value 
 * contained in an array
 * @param Object Array to use for checking
 * @param String|Object the String or Object to check
 */
Array.indexOf = function(arr, val) {
   var i = -1;
   while (i++ < arr.length -1) {
      if (arr[i] == val)
         return i;
   }
   return -1;
};


/**
 * return the last index position of a value 
 * contained in an array
 * @param Object Array to use for checking
 * @param String|Object the String or Object to check
 */
Array.lastIndexOf = function(arr, val) {
   var i = 1;
   while (arr.length - i++ >= 0) {
      if (arr[i] == val)
         return i;
   }
   return -1;
};


/**
 * check if an array passed as argument contains
 * a specific value (start from end of array)
 * @param Object Array to use for checking
 * @param String|Object the String or Object to check
 */
Array.contains = function(arr, val) {
   if (Array.indexOf(arr, val) > -1)
      return true;
   return false;
};


/**
 * retrieve the union set of a bunch of arrays
 * @param Array (Array2, ...) the arrays to unify
 * @return Array the union set
 */
Array.union = function() {
   var result = [];
   var map = {};
   for (var i=0; i<arguments.length; i+=1) {
      for (var n in arguments[i]) {
         var item = arguments[i][n];
         if (!map[item]) {
            result.push(item);
            map[item] = true;
         }
      }
   }
   return result;
};


/**
 * retrieve the intersection set of a bunch of arrays
 * @param Array (Array2, ...) the arrays to intersect
 * @return Array the intersection set
 */
Array.intersection = function() {
   var all = Array.union.apply(this, arguments);
   var result = [];
   for (var n in all) {
      var chksum = 0;
      var item = all[n];
      for (var i=0; i<arguments.length; i+=1) {
         if (Array.contains(arguments[i], item))
            chksum += 1;
         else
            break;
      }
      if (chksum == arguments.length)
         result.push(item);
   }
   return result;
};
